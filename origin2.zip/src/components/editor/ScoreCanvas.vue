<template>
  <div class="score-editor h-full flex flex-col">
    <!-- 顶部工具栏 -->
    <div class="editor-header bg-white border-b p-4">
      <div class="flex items-center justify-between">
        <div class="flex items-center space-x-4">
          <div class="text-lg font-semibold">
            {{ scoreTitle }}
            <input
              v-if="isEditingTitle"
              v-model="scoreTitle"
              @blur="saveTitle"
              @keyup.enter="saveTitle"
              class="ml-2 border px-2 py-1 rounded"
            />
            <button
              v-else
              @click="startEditingTitle"
              class="ml-2 text-blue-500 hover:text-blue-700"
            >
              编辑
            </button>
          </div>
          
          <div class="flex items-center space-x-2">
            <span class="text-sm text-gray-600">拍号:</span>
            <select v-model="timeSignature.numerator" class="border rounded px-2 py-1">
              <option v-for="n in [2, 3, 4, 6, 9, 12]" :key="n" :value="n">{{ n }}</option>
            </select>
            <span>/</span>
            <select v-model="timeSignature.denominator" class="border rounded px-2 py-1">
              <option v-for="d in [2, 4, 8, 16]" :key="d" :value="d">{{ d }}</option>
            </select>
          </div>
          
          <div class="flex items-center space-x-2">
            <span class="text-sm text-gray-600">调号:</span>
            <select v-model="keySignature" class="border rounded px-2 py-1">
              <option v-for="key in keySignatures" :key="key" :value="key">{{ key }}</option>
            </select>
          </div>
        </div>
        
        <div class="flex items-center space-x-3">
          <!-- 历史记录管理器 -->
          <HistoryManager
            ref="historyManager"
            :score="currentScore"
            :show-history-info="true"
            @state-change="restoreScoreState"
          />
          
          <button
            class="px-4 py-2 bg-green-500 text-white rounded hover:bg-green-600 transition"
            @click="playComposition"
          >
            ▶️ 播放
          </button>
          <button
            class="px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600 transition"
            @click="saveScore"
          >
            💾 保存
          </button>
          <button
            class="px-4 py-2 bg-purple-500 text-white rounded hover:bg-purple-600 transition"
            @click="exportMidi"
          >
            📥 导出
          </button>
        </div>
      </div>
      
      <!-- 速度和节拍器控制 -->
      <div class="mt-4 flex items-center space-x-6">
        <div class="flex items-center space-x-2">
          <span class="text-sm text-gray-600">速度:</span>
          <input
            type="range"
            min="40"
            max="200"
            v-model="tempo"
            class="w-32"
          />
          <span class="w-12">{{ tempo }} BPM</span>
        </div>
        
        <div class="flex items-center space-x-2">
          <button
            :class="['px-3 py-1 rounded', metronomeOn ? 'bg-red-500 text-white' : 'bg-gray-200']"
            @click="toggleMetronome"
          >
            {{ metronomeOn ? '⏹️ 停止节拍器' : '🎵 启动节拍器' }}
          </button>
        </div>
      </div>
    </div>
    
    <!-- 主编辑区域 -->
    <div class="flex flex-1 overflow-hidden">
      <!-- 左侧工具面板 -->
      <div class="w-64 border-r bg-gray-50 p-4 overflow-y-auto">
        <MusicToolbar
          @note-selected="handleNoteSelected"
          @pitch-selected="handlePitchSelected"
        />
        
        <!-- 附加工具 -->
        <div class="mt-6 space-y-4">
          <h4 class="font-medium text-gray-700">附加工具</h4>
          
          <div class="space-y-2">
            <button
              class="w-full px-3 py-2 text-left border rounded hover:bg-gray-100 transition"
              @click="addRest"
            >
              🎵 添加休止符
            </button>
            <button
              class="w-full px-3 py-2 text-left border rounded hover:bg-gray-100 transition"
              @click="addChord"
            >
              🎹 添加和弦
            </button>
            <button
              class="w-full px-3 py-2 text-left border rounded hover:bg-gray-100 transition"
              @click="undoAction"
            >
              ↩️ 撤销
            </button>
            <button
              class="w-full px-3 py-2 text-left border rounded hover:bg-gray-100 transition"
              @click="redoAction"
            >
              ↪️ 重做
            </button>
          </div>
        </div>
      </div>
      
      <!-- 乐谱画布 -->
      <div class="flex-1 flex flex-col">
        <!-- 乐谱行号 -->
        <div class="border-b bg-gray-50 px-4 py-2">
          <div class="flex space-x-8 text-sm text-gray-600">
            <div v-for="i in 10" :key="i" class="w-16 text-center">
              第 {{ i }} 小节
            </div>
          </div>
        </div>
        
        <!-- 乐谱显示区域 -->
        <div
          ref="canvasContainer"
          class="flex-1 bg-white p-8 overflow-auto relative"
          @click="handleCanvasClick"
        >
          <div class="score-display-area relative" :style="{ minWidth: '800px', minHeight: '600px' }">
            <!-- 可拖拽音符 -->
            <DraggableNote
              v-for="note in notes"
              :key="note.id"
              :note="note"
              @select="selectNote"
              @move="moveNote"
              @drag-start="onDragStart"
              @drag-end="onDragEnd"
            />
            
            <!-- 五线谱背景（使用canvas） -->
            <canvas ref="canvas" class="absolute inset-0 pointer-events-none"></canvas>
          </div>
        </div>
      </div>
      
      <!-- 右侧属性面板 -->
      <div class="w-80 border-l bg-gray-50 p-4 overflow-y-auto">
        <h4 class="font-medium text-gray-700 mb-4">属性面板</h4>
        
        <!-- 音频播放器 -->
        <AudioPlayer
          :notes="notes"
          :tempo="tempo"
          @playback-start="onPlaybackStart"
          @playback-stop="onPlaybackStop"
          @playback-pause="onPlaybackPause"
          @current-note-change="onCurrentNoteChange"
          class="mb-4"
        />
        
        <!-- 音符编辑器 -->
        <NoteEditor
          v-if="selectedNote"
          :note="selectedNote"
          @change="updateSelectedNote"
          @apply="applyNoteChanges"
          @reset="resetNoteChanges"
        />
        
        <!-- 乐谱整体信息 -->
        <div v-else class="space-y-4">
          <div class="border rounded-lg p-3 bg-white">
            <h5 class="font-medium mb-2">乐谱信息</h5>
            <div class="space-y-2 text-sm">
              <div class="flex justify-between">
                <span class="text-gray-600">总音符数:</span>
                <span class="font-medium">{{ notes.length }}</span>
              </div>
              <div class="flex justify-between">
                <span class="text-gray-600">总时长:</span>
                <span class="font-medium">{{ totalDuration }}拍</span>
              </div>
              <div class="flex justify-between">
                <span class="text-gray-600">创建时间:</span>
                <span class="font-medium">{{ formatDate(createdAt) }}</span>
              </div>
              <div class="flex justify-between">
                <span class="text-gray-600">最后修改:</span>
                <span class="font-medium">{{ formatDate(updatedAt) }}</span>
              </div>
            </div>
          </div>
          
          <!-- 乐谱设置 -->
          <div class="border rounded-lg p-3 bg-white">
            <h5 class="font-medium mb-2">乐谱设置</h5>
            <div class="space-y-3">
              <div>
                <label class="block text-xs text-gray-600 mb-1">拍号</label>
                <div class="flex items-center space-x-2">
                  <select 
                    v-model="timeSignature.numerator"
                    class="flex-1 border rounded px-2 py-1 text-sm"
                  >
                    <option v-for="n in [2, 3, 4, 6, 9, 12]" :key="n" :value="n">{{ n }}</option>
                  </select>
                  <span class="text-gray-500">/</span>
                  <select 
                    v-model="timeSignature.denominator"
                    class="flex-1 border rounded px-2 py-1 text-sm"
                  >
                    <option v-for="d in [2, 4, 8, 16]" :key="d" :value="d">{{ d }}</option>
                  </select>
                </div>
              </div>
              
              <div>
                <label class="block text-xs text-gray-600 mb-1">调号</label>
                <select 
                  v-model="keySignature"
                  class="w-full border rounded px-2 py-1 text-sm"
                >
                  <option v-for="key in keySignatures" :key="key" :value="key">{{ key }}</option>
                </select>
              </div>
              
              <div>
                <label class="block text-xs text-gray-600 mb-1">速度 (BPM)</label>
                <div class="flex items-center space-x-2">
                  <input
                    type="range"
                    min="40"
                    max="200"
                    v-model="tempo"
                    class="flex-1"
                  />
                  <span class="w-12 text-sm">{{ tempo }}</span>
                </div>
              </div>
            </div>
          </div>
        </div>
        
        <!-- 乐谱信息 -->
        <div class="mt-6 border rounded-lg p-3 bg-white">
          <h5 class="font-medium mb-2">乐谱信息</h5>
          <div class="space-y-2 text-sm">
            <div class="flex justify-between">
              <span class="text-gray-600">总音符数:</span>
              <span class="font-medium">{{ notes.length }}</span>
            </div>
            <div class="flex justify-between">
              <span class="text-gray-600">总时长:</span>
              <span class="font-medium">{{ totalDuration }}拍</span>
            </div>
            <div class="flex justify-between">
              <span class="text-gray-600">创建时间:</span>
              <span class="font-medium">{{ formatDate(createdAt) }}</span>
            </div>
            <div class="flex justify-between">
              <span class="text-gray-600">最后修改:</span>
              <span class="font-medium">{{ formatDate(updatedAt) }}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
    
    <!-- 底部状态栏 -->
    <div class="border-t bg-gray-800 text-white px-4 py-2 text-sm">
      <div class="flex justify-between">
        <div>
          状态: <span class="text-green-400">已就绪</span> |
          当前工具: <span class="font-medium">{{ currentTool }}</span>
        </div>
        <div>
          位置: X={{ mouseX }}, Y={{ mouseY }} |
          缩放: {{ zoomLevel }}%
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted, watch, computed } from 'vue'
import { useRoute } from 'vue-router'
import dayjs from 'dayjs'
import { useScoreStore } from '@/stores/scoreStore'
import MusicToolbar from '@/components/common/MusicToolbar.vue'
import NoteEditor from '@/components/editor/NoteEditor.vue'
import DraggableNote from '@/components/editor/DraggableNote.vue'
import HistoryManager from '@/components/editor/HistoryManager.vue'
import AudioPlayer from '@/components/editor/AudioPlayer.vue'
import type { Note } from '@/types/score'

// 路由参数
const route = useRoute()
const scoreId = computed(() => route.params.id as string)

// 状态管理
const scoreStore = useScoreStore()
const currentScore = computed(() => scoreStore.currentScore)

// 响应式状态
const scoreTitle = ref('未命名乐谱')
const isEditingTitle = ref(false)
const timeSignature = ref({ numerator: 4, denominator: 4 })
const keySignature = ref('C')
const tempo = ref(120)
const metronomeOn = ref(false)
const selectedNote = ref<Note | null>(null)
const mouseX = ref(0)
const mouseY = ref(0)
const zoomLevel = ref(100)
const currentTool = ref('音符工具')

// 调号选项
const keySignatures = ['C', 'G', 'D', 'A', 'E', 'B', 'F#', 'C#', 'F', 'Bb', 'Eb', 'Ab', 'Db', 'Gb', 'Cb']

// 计算属性
const notes = computed(() => currentScore.value?.notes || [])
const totalDuration = computed(() => {
  return notes.value.reduce((total, note) => total + note.duration, 0)
})
const createdAt = computed(() => currentScore.value?.createdAt || new Date())
const updatedAt = computed(() => currentScore.value?.updatedAt || new Date())

// 画布引用
const canvas = ref<HTMLCanvasElement>()
const canvasContainer = ref<HTMLDivElement>()
const historyManager = ref<InstanceType<typeof HistoryManager> | null>(null)

// 方法
const handleNoteSelected = (type: string) => {
  currentTool.value = `${type}音符`
}

const handlePitchSelected = (pitch: string) => {
  if (selectedNote.value) {
    selectedNote.value.pitch = pitch
  }
}

const handleCanvasClick = (event: MouseEvent) => {
  if (!canvasContainer.value) return
  
  const rect = canvasContainer.value.getBoundingClientRect()
  mouseX.value = Math.round(event.clientX - rect.left)
  mouseY.value = Math.round(event.clientY - rect.top)
  
  // 取消选择
  if (selectedNote.value) {
    selectedNote.value.isSelected = false
    selectedNote.value = null
  }
}

const selectNote = (note: Note) => {
  // 取消之前选中的音符
  if (selectedNote.value) {
    selectedNote.value.isSelected = false
  }
  
  // 选择新音符
  note.isSelected = true
  selectedNote.value = note
}

const moveNote = (noteId: string, newPosition: { x: number; y: number }) => {
  const note = notes.value.find(n => n.id === noteId)
  if (note) {
    note.position = newPosition
    // 更新store
    scoreStore.updateNote(noteId, note)
  }
}

const onDragStart = (note: Note) => {
  currentTool.value = '拖拽音符'
  console.log('开始拖拽音符:', note.id)
}

const onDragEnd = (note: Note) => {
  currentTool.value = '音符工具'
  console.log('结束拖拽音符:', note.id)
  // 触发自动保存
  saveScore()
}

const startEditingTitle = () => {
  isEditingTitle.value = true
}

const saveTitle = () => {
  isEditingTitle.value = false
  if (currentScore.value) {
    currentScore.value.title = scoreTitle.value
  }
}

const playComposition = () => {
  // 实现播放逻辑
  console.log('播放乐谱')
}

const restoreScoreState = (score: any) => {
  // 恢复乐谱状态
  if (currentScore.value) {
    Object.assign(currentScore.value, score)
    scoreTitle.value = score.title
    timeSignature.value = score.timeSignature
    keySignature.value = score.keySignature
    tempo.value = score.tempo
    
    // 更新选中的音符引用
    if (selectedNote.value) {
      const restoredNote = score.notes.find((n: Note) => n.id === selectedNote.value!.id)
      if (restoredNote) {
        selectedNote.value = restoredNote
      } else {
        selectedNote.value = null
      }
    }
  }
}

const saveScore = () => {
  // 实现保存逻辑
  if (currentScore.value) {
    currentScore.value.updatedAt = new Date()
    scoreStore.updateScore(currentScore.value.id, currentScore.value)
    
    // 保存到历史记录
    if (historyManager.value) {
      historyManager.value.saveState(currentScore.value)
    }
    
    console.log('乐谱已保存')
  }
}

const exportMidi = () => {
  // 实现导出逻辑
  console.log('导出MIDI')
}

const toggleMetronome = () => {
  metronomeOn.value = !metronomeOn.value
}

const addRest = () => {
  // 添加休止符
  console.log('添加休止符')
}

const addChord = () => {
  // 添加和弦
  console.log('添加和弦')
}

const undoAction = () => {
  // 撤销操作
  console.log('撤销')
}

const redoAction = () => {
  // 重做操作
  console.log('重做')
}

const deleteSelectedNote = () => {
  if (selectedNote.value) {
    scoreStore.removeNote(selectedNote.value.id)
    selectedNote.value = null
  }
}

const updateSelectedNote = (changes: Partial<Note>) => {
  if (selectedNote.value) {
    Object.assign(selectedNote.value, changes)
    // 更新store中的音符
    const noteIndex = notes.value.findIndex(n => n.id === selectedNote.value!.id)
    if (noteIndex > -1) {
      Object.assign(notes.value[noteIndex], changes)
    }
  }
}

const applyNoteChanges = () => {
  if (selectedNote.value) {
    scoreStore.updateNote(selectedNote.value.id, selectedNote.value)
    console.log('音符更改已应用')
  }
}

const resetNoteChanges = () => {
  if (selectedNote.value) {
    // 从store重新加载音符数据
    const originalNote = notes.value.find(n => n.id === selectedNote.value!.id)
    if (originalNote) {
      Object.assign(selectedNote.value, originalNote)
    }
    console.log('音符更改已重置')
  }
}

const onPlaybackStart = () => {
  currentTool.value = '播放中'
  console.log('开始播放')
}

const onPlaybackStop = () => {
  currentTool.value = '音符工具'
  console.log('停止播放')
}

const onPlaybackPause = () => {
  currentTool.value = '暂停播放'
  console.log('暂停播放')
}

const onCurrentNoteChange = (noteIndex: number) => {
  // 高亮当前播放的音符
  notes.value.forEach((note, index) => {
    note.isSelected = index === noteIndex
  })
  
  // 更新选中的音符
  if (noteIndex < notes.value.length) {
    selectedNote.value = notes.value[noteIndex]
  }
  
  console.log(`当前播放第 ${noteIndex + 1} 个音符`)
}

const formatDate = (date: Date) => {
  return dayjs(date).format('YYYY-MM-DD HH:mm')
}

// 初始化画布
onMounted(() => {
  if (scoreId.value) {
    // 加载指定乐谱
    const score = scoreStore.scores.find(s => s.id === scoreId.value)
    if (score) {
      scoreStore.currentScore = score
      scoreTitle.value = score.title
      timeSignature.value = score.timeSignature
      keySignature.value = score.keySignature
      tempo.value = score.tempo
    }
  }
  
  // 初始化画布
  const ctx = canvas.value?.getContext('2d')
  if (ctx && canvas.value && canvasContainer.value) {
    canvas.value.width = canvasContainer.value.clientWidth
    canvas.value.height = canvasContainer.value.clientHeight
    
    // 绘制五线谱
    drawStaff(ctx)
  }
})

const drawStaff = (ctx: CanvasRenderingContext2D) => {
  ctx.strokeStyle = '#000'
  ctx.lineWidth = 1
  
  // 绘制多个五线谱系统
  for (let system = 0; system < 3; system++) {
    const yOffset = 50 + system * 200
    
    for (let i = 0; i < 5; i++) {
      const y = yOffset + i * 20
      ctx.beginPath()
      ctx.moveTo(50, y)
      ctx.lineTo(ctx.canvas.width - 50, y)
      ctx.stroke()
    }
    
    // 绘制小节线
    for (let i = 0; i < 4; i++) {
      const x = 50 + i * 200
      ctx.beginPath()
      ctx.moveTo(x, yOffset)
      ctx.lineTo(x, yOffset + 80)
      ctx.stroke()
    }
  }
}

// 监听画布容器大小变化
watch(canvasContainer, () => {
  if (canvas.value && canvasContainer.value) {
    canvas.value.width = canvasContainer.value.clientWidth
    canvas.value.height = canvasContainer.value.clientHeight
    
    const ctx = canvas.value.getContext('2d')
    if (ctx) {
      drawStaff(ctx)
    }
  }
}, { immediate: true })
</script>

<style scoped>
.score-editor {
  height: calc(100vh - 64px); /* 减去header高度 */
}

.score-display-area {
  background: linear-gradient(to right, #f9f9f9 0%, #fff 20px, #fff calc(100% - 20px), #f9f9f9 100%);
}

canvas {
  background: white;
  border: 1px solid #e5e7eb;
  border-radius: 4px;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
}
</style>