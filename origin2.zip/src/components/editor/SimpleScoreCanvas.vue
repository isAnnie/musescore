<template>
  <div class="score-editor h-full flex flex-col bg-gray-100">
    <!-- 调试信息 -->
    <div class="debug-info p-2 bg-yellow-100 border-b">
      <p>当前乐谱ID: {{ scoreId }}</p>
      <p>当前乐谱存在: {{ !!currentScore }}</p>
      <p>音符数量: {{ notes.length }}</p>
    </div>
    
    <!-- 顶部工具栏 -->
    <div class="editor-header bg-white border-b p-4">
      <div class="flex items-center justify-between">
        <div class="flex items-center space-x-4">
          <div class="text-lg font-semibold">
            {{ scoreTitle || '未命名乐谱' }}
          </div>
          
          <div class="flex items-center space-x-2">
            <span class="text-sm text-gray-600">拍号:</span>
            <select v-model="timeSignature.numerator" class="border rounded px-2 py-1">
              <option v-for="n in [2, 3, 4, 6, 9, 12]" :key="n" :value="n">{{ n }}</option>
            </select>
            <span>/</span>
            <select v-model="timeSignature.denominator" class="border rounded px-2 py-1">
              <option v-for="d in [2, 4, 8, 16]" :key="d" :value="d">{{ d }}</option>
            </select>
          </div>
        </div>
        
        <div class="flex items-center space-x-3">
          <button
            class="px-4 py-2 bg-green-500 text-white rounded hover:bg-green-600 transition"
            @click="addTestNote"
          >
            ➕ 添加测试音符
          </button>
          <button
            class="px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600 transition"
            @click="saveScore"
          >
            💾 保存
          </button>
        </div>
      </div>
    </div>
    
    <!-- 主编辑区域 -->
    <div class="flex flex-1 overflow-hidden">
      <!-- 左侧工具面板 -->
      <div class="w-64 border-r bg-gray-50 p-4 overflow-y-auto">
        <h4 class="font-medium text-gray-700 mb-4">工具面板</h4>
        <div class="space-y-2">
          <button
            class="w-full px-3 py-2 bg-white border rounded hover:bg-gray-50 transition"
            @click="addQuarterNote"
          >
            四分音符
          </button>
          <button
            class="w-full px-3 py-2 bg-white border rounded hover:bg-gray-50 transition"
            @click="addHalfNote"
          >
            二分音符
          </button>
        </div>
      </div>
      
      <!-- 乐谱画布 -->
      <div class="flex-1 flex flex-col">
        <!-- 乐谱显示区域 -->
        <div
          ref="canvasContainer"
          class="flex-1 bg-white p-8 overflow-auto relative"
          @click="handleCanvasClick"
        >
          <div class="score-display-area relative border" :style="{ minWidth: '800px', minHeight: '600px' }">
            <!-- 背景网格 -->
            <div class="absolute inset-0 opacity-10">
              <div v-for="i in 20" :key="i" class="absolute w-full h-px bg-gray-400" 
                   :style="{ top: (i * 30) + 'px' }"></div>
              <div v-for="i in 30" :key="i" class="absolute h-full w-px bg-gray-400" 
                   :style="{ left: (i * 30) + 'px' }"></div>
            </div>
            
            <!-- 可拖拽音符 -->
            <DraggableNote
              v-for="note in notes"
              :key="note.id"
              :note="note"
              @select="selectNote"
              @move="moveNote"
              @drag-start="onDragStart"
              @drag-end="onDragEnd"
            />
            
            <!-- 点击位置指示器 -->
            <div 
              v-if="mouseX > 0 && mouseY > 0"
              class="absolute w-2 h-2 bg-red-500 rounded-full pointer-events-none"
              :style="{ left: mouseX + 'px', top: mouseY + 'px' }"
            ></div>
          </div>
        </div>
      </div>
      
      <!-- 右侧属性面板 -->
      <div class="w-80 border-l bg-gray-50 p-4 overflow-y-auto">
        <h4 class="font-medium text-gray-700 mb-4">属性面板</h4>
        
        <div v-if="selectedNote" class="bg-white p-4 rounded border">
          <h5 class="font-medium mb-2">选中的音符</h5>
          <div class="space-y-2 text-sm">
            <div>ID: {{ selectedNote.id }}</div>
            <div>类型: {{ selectedNote.type }}</div>
            <div>音高: {{ selectedNote.pitch }}</div>
            <div>位置: X={{ selectedNote.position.x }}, Y={{ selectedNote.position.y }}</div>
            <button 
              @click="deleteSelectedNote"
              class="mt-2 px-3 py-1 bg-red-500 text-white rounded text-sm"
            >
              删除音符
            </button>
          </div>
        </div>
        
        <div v-else class="bg-white p-4 rounded border">
          <h5 class="font-medium mb-2">乐谱信息</h5>
          <div class="space-y-2 text-sm">
            <div>总音符数: {{ notes.length }}</div>
            <div>创建时间: {{ formatDate(createdAt) }}</div>
          </div>
        </div>
      </div>
    </div>
    
    <!-- 底部状态栏 -->
    <div class="border-t bg-gray-800 text-white px-4 py-2 text-sm">
      <div class="flex justify-between">
        <div>
          状态: <span class="text-green-400">运行中</span> |
          音符数: {{ notes.length }}
        </div>
        <div>
          鼠标位置: X={{ mouseX }}, Y={{ mouseY }}
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted, computed } from 'vue'
import { useRoute } from 'vue-router'
import { useScoreStore } from '@/stores/scoreStore'
import DraggableNote from '@/components/editor/DraggableNote.vue'
import type { Note } from '@/types/score'
import dayjs from 'dayjs'

// 路由参数
const route = useRoute()
const scoreId = computed(() => route.params.id as string)

// 状态管理
const scoreStore = useScoreStore()
const currentScore = computed(() => scoreStore.currentScore)

// 响应式状态
const scoreTitle = ref('测试乐谱')
const timeSignature = ref({ numerator: 4, denominator: 4 })
const selectedNote = ref<Note | null>(null)
const mouseX = ref(0)
const mouseY = ref(0)

// 计算属性
const notes = computed(() => currentScore.value?.notes || [])
const createdAt = computed(() => currentScore.value?.createdAt || new Date())

// 画布引用
const canvasContainer = ref<HTMLDivElement>()

// 方法
const handleCanvasClick = (event: MouseEvent) => {
  if (!canvasContainer.value) return
  
  const rect = canvasContainer.value.getBoundingClientRect()
  mouseX.value = Math.round(event.clientX - rect.left)
  mouseY.value = Math.round(event.clientY - rect.top)
  
  // 创建新音符
  const note: Note = {
    id: Date.now().toString(),
    type: 'quarter',
    pitch: 'C4',
    duration: 1,
    position: { x: mouseX.value, y: mouseY.value }
  }
  
  scoreStore.addNote(note)
  selectedNote.value = note
}

const selectNote = (note: Note) => {
  // 取消之前选中的音符
  if (selectedNote.value) {
    selectedNote.value.isSelected = false
  }
  
  // 选择新音符
  note.isSelected = true
  selectedNote.value = note
}

const moveNote = (noteId: string, newPosition: { x: number; y: number }) => {
  const note = notes.value.find(n => n.id === noteId)
  if (note) {
    note.position = newPosition
  }
}

const onDragStart = (note: Note) => {
  console.log('开始拖拽音符:', note.id)
}

const onDragEnd = (note: Note) => {
  console.log('结束拖拽音符:', note.id)
}

const deleteSelectedNote = () => {
  if (selectedNote.value) {
    scoreStore.removeNote(selectedNote.value.id)
    selectedNote.value = null
  }
}

const addTestNote = () => {
  const note: Note = {
    id: Date.now().toString(),
    type: 'quarter',
    pitch: 'C4',
    duration: 1,
    position: { x: 100 + Math.random() * 200, y: 100 + Math.random() * 200 }
  }
  scoreStore.addNote(note)
}

const addQuarterNote = () => {
  const note: Note = {
    id: Date.now().toString(),
    type: 'quarter',
    pitch: 'D4',
    duration: 1,
    position: { x: 150, y: 150 }
  }
  scoreStore.addNote(note)
}

const addHalfNote = () => {
  const note: Note = {
    id: Date.now().toString(),
    type: 'half',
    pitch: 'E4',
    duration: 2,
    position: { x: 200, y: 200 }
  }
  scoreStore.addNote(note)
}

const saveScore = () => {
  if (currentScore.value) {
    currentScore.value.updatedAt = new Date()
    console.log('乐谱已保存:', currentScore.value)
  }
}

const formatDate = (date: Date) => {
  return dayjs(date).format('YYYY-MM-DD HH:mm')
}

// 初始化
onMounted(() => {
  console.log('ScoreCanvas mounted')
  console.log('scoreId:', scoreId.value)
  console.log('currentScore:', currentScore.value)
  
  // 如果没有当前乐谱，创建一个测试乐谱
  if (!currentScore.value && scoreId.value) {
    const score = scoreStore.scores.find(s => s.id === scoreId.value)
    if (score) {
      scoreStore.currentScore = score
      scoreTitle.value = score.title
    } else {
      // 创建新乐谱
      const newScore = scoreStore.createScore('新乐谱')
      scoreStore.currentScore = newScore
      scoreTitle.value = newScore.title
    }
  } else if (!currentScore.value) {
    // 创建默认乐谱
    const newScore = scoreStore.createScore('默认乐谱')
    scoreStore.currentScore = newScore
    scoreTitle.value = newScore.title
  }
})
</script>

<style scoped>
.score-editor {
  height: calc(100vh - 64px);
}

.score-display-area {
  background: white;
}
</style>