<template>
  <div class="audio-player bg-white rounded-lg border p-4">
    <div class="flex items-center justify-between mb-4">
      <h3 class="font-medium text-gray-800">音频播放器</h3>
      <div class="flex items-center space-x-2">
        <span class="text-sm text-gray-600">{{ playbackStatus }}</span>
        <div 
          v-if="isPlaying" 
          class="w-2 h-2 bg-red-500 rounded-full animate-pulse"
        ></div>
      </div>
    </div>
    
    <!-- 控制按钮 -->
    <div class="flex items-center justify-center space-x-4 mb-4">
      <button
        @click="skipBackward"
        class="p-2 rounded-full hover:bg-gray-100 transition"
        title="上一个音符"
      >
        <svg class="w-6 h-6" fill="currentColor" viewBox="0 0 20 20">
          <path fill-rule="evenodd" d="M12.707 5.293a1 1 0 010 1.414L9.414 10l3.293 3.293a1 1 0 01-1.414 1.414l-4-4a1 1 0 010-1.414l4-4a1 1 0 011.414 0z" clip-rule="evenodd"/>
        </svg>
      </button>
      
      <button
        v-if="!isPlaying"
        @click="play"
        class="p-3 rounded-full bg-green-500 text-white hover:bg-green-600 transition"
        title="播放"
      >
        <svg class="w-8 h-8" fill="currentColor" viewBox="0 0 20 20">
          <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM9.555 7.168A1 1 0 008 8v4a1 1 0 001.555.832l3-2a1 1 0 000-1.664l-3-2z" clip-rule="evenodd"/>
        </svg>
      </button>
      
      <button
        v-else
        @click="pause"
        class="p-3 rounded-full bg-yellow-500 text-white hover:bg-yellow-600 transition"
        title="暂停"
      >
        <svg class="w-8 h-8" fill="currentColor" viewBox="0 0 20 20">
          <path fill-rule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zM7 8a1 1 0 012 0v4a1 1 0 11-2 0V8zm5-1a1 1 0 00-1 1v4a1 1 0 102 0V8a1 1 0 00-1-1z" clip-rule="evenodd"/>
        </svg>
      </button>
      
      <button
        @click="skipForward"
        class="p-2 rounded-full hover:bg-gray-100 transition"
        title="下一个音符"
      >
        <svg class="w-6 h-6" fill="currentColor" viewBox="0 0 20 20">
          <path fill-rule="evenodd" d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z" clip-rule="evenodd"/>
        </svg>
      </button>
      
      <button
        @click="stop"
        class="p-2 rounded-full hover:bg-gray-100 transition"
        title="停止"
      >
        <svg class="w-6 h-6" fill="currentColor" viewBox="0 0 20 20">
          <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8 7a1 1 0 00-1 1v4a1 1 0 001 1h4a1 1 0 001-1V8a1 1 0 00-1-1H8z" clip-rule="evenodd"/>
        </svg>
      </button>
    </div>
    
    <!-- 进度条 -->
    <div class="mb-4">
      <div class="flex justify-between text-sm text-gray-600 mb-1">
        <span>{{ formatTime(currentTime) }}</span>
        <span>{{ formatTime(totalTime) }}</span>
      </div>
      <div 
        class="w-full h-2 bg-gray-200 rounded-full cursor-pointer"
        @click="seekTo"
      >
        <div 
          class="h-full bg-blue-500 rounded-full transition-all"
          :style="{ width: progressPercentage + '%' }"
        ></div>
      </div>
    </div>
    
    <!-- 音量控制 -->
    <div class="flex items-center space-x-3 mb-4">
      <svg class="w-5 h-5 text-gray-600" fill="currentColor" viewBox="0 0 20 20">
        <path fill-rule="evenodd" d="M9.383 3.076A1 1 0 0110 4v12a1 1 0 01-1.707.707L4.586 13H2a1 1 0 01-1-1V8a1 1 0 011-1h2.586l3.707-3.707a1 1 0 011.09-.217zM14.657 2.929a1 1 0 011.414 0A9.972 9.972 0 0119 10a9.972 9.972 0 01-2.929 7.071 1 1 0 01-1.414-1.414A7.971 7.971 0 0017 10c0-2.21-.894-4.208-2.343-5.657a1 1 0 010-1.414zm-2.829 2.828a1 1 0 011.415 0A5.983 5.983 0 0115 10a5.984 5.984 0 01-1.757 4.243 1 1 0 01-1.415-1.415A3.984 3.984 0 0013 10a3.983 3.983 0 00-1.172-2.828 1 1 0 010-1.415z" clip-rule="evenodd"/>
      </svg>
      <input
        type="range"
        min="0"
        max="100"
        v-model="volume"
        class="flex-1"
        @input="setVolume"
      />
      <span class="text-sm text-gray-600 w-10">{{ volume }}%</span>
    </div>
    
    <!-- 播放模式 -->
    <div class="flex items-center justify-between">
      <div class="flex items-center space-x-2">
        <span class="text-sm text-gray-600">播放模式:</span>
        <select 
          v-model="playMode"
          class="border rounded px-2 py-1 text-sm"
          @change="changePlayMode"
        >
          <option value="normal">顺序播放</option>
          <option value="loop">单曲循环</option>
          <option value="repeat">全部循环</option>
        </select>
      </div>
      
      <div class="flex items-center space-x-2">
        <span class="text-sm text-gray-600">速度:</span>
        <select 
          v-model="playbackRate"
          class="border rounded px-2 py-1 text-sm"
          @change="changePlaybackRate"
        >
          <option :value="0.5">0.5x</option>
          <option :value="0.75">0.75x</option>
          <option :value="1">1x</option>
          <option :value="1.25">1.25x</option>
          <option :value="1.5">1.5x</option>
          <option :value="2">2x</option>
        </select>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted, onUnmounted } from 'vue'
import * as Tone from 'tone'
import type { Note } from '@/types/score'

const props = defineProps<{
  notes: Note[]
  tempo: number
}>()

const emit = defineEmits<{
  (e: 'playback-start'): void
  (e: 'playback-stop'): void
  (e: 'playback-pause'): void
  (e: 'current-note-change', noteIndex: number): void
}>()

// 音频状态
const isPlaying = ref(false)
const currentTime = ref(0)
const totalTime = ref(0)
const currentNoteIndex = ref(0)
const volume = ref(80)
const playMode = ref<'normal' | 'loop' | 'repeat'>('normal')
const playbackRate = ref(1)

// Tone.js 相关
const synth = ref<any>(null)
const sequence = ref<any>(null)
const timerId = ref<number | null>(null)

// 计算属性
const progressPercentage = computed(() => {
  return totalTime.value > 0 ? (currentTime.value / totalTime.value) * 100 : 0
})

const playbackStatus = computed(() => {
  if (!isPlaying.value) return '已停止'
  return `播放中 - 第 ${currentNoteIndex.value + 1}/${props.notes.length} 个音符`
})

// 格式化时间
const formatTime = (seconds: number) => {
  const mins = Math.floor(seconds / 60)
  const secs = Math.floor(seconds % 60)
  return `${mins}:${secs.toString().padStart(2, '0')}`
}

// 音频控制方法
const initAudio = async () => {
  try {
    // 等待用户交互后初始化音频上下文
    await Tone.start()
    
    synth.value = new Tone.PolySynth(Tone.Synth).toDestination()
    synth.value.volume.value = Tone.gainToDb(volume.value / 100)
    
    // 设置初始参数
    Tone.Transport.bpm.value = props.tempo
    Tone.Transport.playbackRate = playbackRate.value
    
    console.log('音频系统初始化完成')
  } catch (error) {
    console.error('音频初始化失败:', error)
  }
}

const play = async () => {
  if (!synth.value) {
    await initAudio()
  }
  
  if (props.notes.length === 0) {
    console.warn('没有音符可以播放')
    return
  }
  
  isPlaying.value = true
  emit('playback-start')
  
  // 开始播放序列
  startSequence()
}

const pause = () => {
  isPlaying.value = false
  Tone.Transport.pause()
  emit('playback-pause')
  
  if (timerId.value) {
    clearInterval(timerId.value)
  }
}

const stop = () => {
  isPlaying.value = false
  Tone.Transport.stop()
  currentNoteIndex.value = 0
  currentTime.value = 0
  emit('playback-stop')
  
  if (timerId.value) {
    clearInterval(timerId.value)
  }
}

const skipForward = () => {
  if (currentNoteIndex.value < props.notes.length - 1) {
    currentNoteIndex.value++
    triggerNote(props.notes[currentNoteIndex.value])
  }
}

const skipBackward = () => {
  if (currentNoteIndex.value > 0) {
    currentNoteIndex.value--
    triggerNote(props.notes[currentNoteIndex.value])
  }
}

const seekTo = (event: MouseEvent) => {
  const rect = (event.target as HTMLElement).getBoundingClientRect()
  const percent = (event.clientX - rect.left) / rect.width
  const targetTime = totalTime.value * percent
  
  // 计算对应的小节数
  const targetNoteIndex = Math.floor((targetTime / totalTime.value) * props.notes.length)
  currentNoteIndex.value = Math.max(0, Math.min(props.notes.length - 1, targetNoteIndex))
  
  if (isPlaying.value) {
    triggerNote(props.notes[currentNoteIndex.value])
  }
}

const setVolume = () => {
  if (synth.value) {
    synth.value.volume.value = Tone.gainToDb(volume.value / 100)
  }
}

const changePlayMode = () => {
  console.log('播放模式改为:', playMode.value)
}

const changePlaybackRate = () => {
  Tone.Transport.playbackRate = playbackRate.value
}

const triggerNote = (note: Note) => {
  if (synth.value) {
    synth.value.triggerAttackRelease(note.pitch, note.duration)
    emit('current-note-change', currentNoteIndex.value)
  }
}

const startSequence = () => {
  // 计算总时间
  totalTime.value = props.notes.reduce((sum, note) => sum + note.duration, 0)
  currentTime.value = 0
  
  // 启动定时器更新进度
  timerId.value = window.setInterval(() => {
    if (isPlaying.value) {
      currentTime.value += 0.1
      
      if (currentTime.value >= totalTime.value) {
        // 播放完成
        if (playMode.value === 'loop') {
          // 单曲循环，重新开始
          currentNoteIndex.value = 0
          currentTime.value = 0
        } else if (playMode.value === 'repeat') {
          // 全部循环
          currentNoteIndex.value = 0
          currentTime.value = 0
        } else {
          // 顺序播放结束
          stop()
        }
      } else {
        // 检查是否需要触发下一个音符
        const expectedNoteIndex = Math.floor((currentTime.value / totalTime.value) * props.notes.length)
        if (expectedNoteIndex !== currentNoteIndex.value && expectedNoteIndex < props.notes.length) {
          currentNoteIndex.value = expectedNoteIndex
          triggerNote(props.notes[currentNoteIndex.value])
        }
      }
    }
  }, 100)
}

// 监听音符变化
const cleanup = () => {
  if (timerId.value) {
    clearInterval(timerId.value)
  }
  if (sequence.value) {
    sequence.value.dispose()
  }
  if (synth.value) {
    synth.value.dispose()
  }
}

// 生命周期
onMounted(() => {
  // 等待用户首次交互后初始化音频
  const initHandler = () => {
    initAudio()
    document.removeEventListener('click', initHandler)
    document.removeEventListener('touchstart', initHandler)
  }
  
  document.addEventListener('click', initHandler)
  document.addEventListener('touchstart', initHandler)
})

onUnmounted(() => {
  cleanup()
})

// 暴露给父组件的方法
defineExpose({
  play,
  pause,
  stop,
  isPlaying: computed(() => isPlaying.value)
})
</script>

<style scoped>
.audio-player {
  min-width: 350px;
}
</style>