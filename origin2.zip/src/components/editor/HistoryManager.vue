<template>
  <div class="history-manager flex items-center space-x-2">
    <button
      :disabled="!canUndo"
      @click="undo"
      :class="[
        'p-2 rounded hover:bg-gray-100 transition',
        canUndo ? 'text-gray-700 hover:text-blue-600' : 'text-gray-400 cursor-not-allowed'
      ]"
      title="撤销 (Ctrl+Z)"
    >
      <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 20 20">
        <path fill-rule="evenodd" d="M7.707 3.293a1 1 0 010 1.414L5.414 7H11a7 7 0 017 7v2a1 1 0 11-2 0v-2a5 5 0 00-5-5H5.414l2.293 2.293a1 1 0 11-1.414 1.414l-4-4a1 1 0 010-1.414l4-4a1 1 0 011.414 0z" clip-rule="evenodd"/>
      </svg>
    </button>
    
    <button
      :disabled="!canRedo"
      @click="redo"
      :class="[
        'p-2 rounded hover:bg-gray-100 transition',
        canRedo ? 'text-gray-700 hover:text-blue-600' : 'text-gray-400 cursor-not-allowed'
      ]"
      title="重做 (Ctrl+Y)"
    >
      <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 20 20">
        <path fill-rule="evenodd" d="M12.293 3.293a1 1 0 011.414 0l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414-1.414L14.586 9H9a7 7 0 00-7 7v2a1 1 0 11-2 0v-2a9 9 0 019-9h5.586l-2.293-2.293a1 1 0 010-1.414z" clip-rule="evenodd"/>
      </svg>
    </button>
    
    <div v-if="showHistoryInfo" class="text-xs text-gray-500">
      {{ historyPosition + 1 }} / {{ history.length }}
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted, onUnmounted } from 'vue'
import type { Score } from '@/types/score'

const props = defineProps<{
  score: Score
  showHistoryInfo?: boolean
}>()

const emit = defineEmits<{
  (e: 'state-change', score: Score): void
}>()

// 历史记录状态
const history = ref<Score[]>([])
const historyPosition = ref(-1)
const MAX_HISTORY_SIZE = 50

// 计算属性
const canUndo = computed(() => historyPosition.value > 0)
const canRedo = computed(() => historyPosition.value < history.value.length - 1)

// 方法
const saveState = (score: Score) => {
  // 如果当前不是最新状态，删除后续的历史记录
  if (historyPosition.value < history.value.length - 1) {
    history.value = history.value.slice(0, historyPosition.value + 1)
  }
  
  // 添加新状态
  const clonedScore = JSON.parse(JSON.stringify(score)) // 深拷贝
  history.value.push(clonedScore)
  historyPosition.value = history.value.length - 1
  
  // 限制历史记录数量
  if (history.value.length > MAX_HISTORY_SIZE) {
    history.value.shift()
    historyPosition.value--
  }
}

const undo = () => {
  if (canUndo.value) {
    historyPosition.value--
    const prevState = history.value[historyPosition.value]
    emit('state-change', JSON.parse(JSON.stringify(prevState)))
  }
}

const redo = () => {
  if (canRedo.value) {
    historyPosition.value++
    const nextState = history.value[historyPosition.value]
    emit('state-change', JSON.parse(JSON.stringify(nextState)))
  }
}

const clearHistory = () => {
  history.value = []
  historyPosition.value = -1
}

const initializeWithScore = (score: Score) => {
  clearHistory()
  saveState(score)
}

// 键盘快捷键
const handleKeyDown = (event: KeyboardEvent) => {
  if (event.ctrlKey || event.metaKey) {
    if (event.key === 'z' && !event.shiftKey) {
      event.preventDefault()
      undo()
    } else if ((event.key === 'y' || (event.key === 'z' && event.shiftKey))) {
      event.preventDefault()
      redo()
    }
  }
}

// 提供给父组件的方法
defineExpose({
  saveState,
  undo,
  redo,
  clearHistory,
  initializeWithScore,
  canUndo,
  canRedo
})

// 生命周期
onMounted(() => {
  document.addEventListener('keydown', handleKeyDown)
})

onUnmounted(() => {
  document.removeEventListener('keydown', handleKeyDown)
})
</script>

<style scoped>
.history-manager {
  user-select: none;
}
</style>