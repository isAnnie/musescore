<template>
  <div class="note-editor bg-white rounded-lg border p-4">
    <h3 class="font-medium text-gray-800 mb-4">音符编辑器</h3>
    
    <!-- 音符类型选择 -->
    <div class="mb-4">
      <label class="block text-sm font-medium text-gray-700 mb-2">音符类型</label>
      <div class="grid grid-cols-5 gap-2">
        <button
          v-for="noteType in noteTypes"
          :key="noteType.value"
          :class="[
            'p-2 rounded border text-center hover:bg-gray-50 transition',
            selectedNoteType === noteType.value 
              ? 'border-blue-500 bg-blue-50 text-blue-700' 
              : 'border-gray-200'
          ]"
          @click="selectNoteType(noteType.value)"
          :title="noteType.label"
        >
          <div class="text-xl mb-1">{{ noteType.symbol }}</div>
          <div class="text-xs">{{ noteType.shortLabel }}</div>
        </button>
      </div>
    </div>
    
    <!-- 音高选择 -->
    <div class="mb-4">
      <label class="block text-sm font-medium text-gray-700 mb-2">音高</label>
      <div class="relative">
        <div class="flex border rounded-lg overflow-hidden">
          <div class="flex-1 bg-gray-50 p-2 text-center">
            <div class="text-2xl font-bold">{{ selectedPitch.name }}</div>
            <div class="text-xs text-gray-600">{{ selectedPitch.octave }}组</div>
          </div>
          <button 
            @click="openPitchSelector"
            class="px-3 bg-white border-l hover:bg-gray-50"
          >
            ▼
          </button>
        </div>
        
        <!-- 音高选择器弹窗 -->
        <div 
          v-if="showPitchSelector"
          class="absolute top-full left-0 right-0 mt-1 bg-white border rounded-lg shadow-lg z-10 p-2"
        >
          <div class="grid grid-cols-7 gap-1">
            <button
              v-for="pitch in allPitches"
              :key="pitch.full"
              :class="[
                'p-2 rounded text-center hover:bg-gray-100',
                selectedPitch.full === pitch.full 
                  ? 'bg-blue-100 text-blue-700 border border-blue-300' 
                  : ''
              ]"
              @click="selectPitch(pitch)"
            >
              <div class="font-medium">{{ pitch.name }}</div>
              <div class="text-xs text-gray-600">{{ pitch.octave }}</div>
            </button>
          </div>
        </div>
      </div>
    </div>
    
    <!-- 时值调节 -->
    <div class="mb-4">
      <label class="block text-sm font-medium text-gray-700 mb-2">时值</label>
      <div class="flex items-center space-x-3">
        <button 
          @click="decreaseDuration"
          class="w-8 h-8 flex items-center justify-center rounded-full bg-gray-100 hover:bg-gray-200"
          :disabled="currentDuration <= 0.25"
        >
          -
        </button>
        <div class="flex-1 text-center">
          <div class="text-lg font-medium">{{ durationDisplay }}</div>
          <div class="text-xs text-gray-600">{{ currentDuration }} 拍</div>
        </div>
        <button 
          @click="increaseDuration"
          class="w-8 h-8 flex items-center justify-center rounded-full bg-gray-100 hover:bg-gray-200"
          :disabled="currentDuration >= 4"
        >
          +
        </button>
      </div>
      
      <!-- 快速时值选择 -->
      <div class="mt-2 flex flex-wrap gap-1">
        <button
          v-for="dur in quickDurations"
          :key="dur.value"
          :class="[
            'px-2 py-1 text-xs rounded',
            currentDuration === dur.value 
              ? 'bg-blue-500 text-white' 
              : 'bg-gray-100 hover:bg-gray-200'
          ]"
          @click="setDuration(dur.value)"
        >
          {{ dur.label }}
        </button>
      </div>
    </div>
    
    <!-- 附加属性 -->
    <div class="space-y-3">
      <div>
        <label class="block text-sm font-medium text-gray-700 mb-2">升降号</label>
        <div class="flex space-x-2">
          <button
            v-for="acc in accidentals"
            :key="acc.value"
            :class="[
              'px-3 py-1 rounded border',
              selectedAccidental === acc.value 
                ? 'border-blue-500 bg-blue-50 text-blue-700' 
                : 'border-gray-200 hover:bg-gray-50'
            ]"
            @click="selectAccidental(acc.value)"
          >
            {{ acc.symbol }} {{ acc.label }}
          </button>
        </div>
      </div>
      
      <div>
        <label class="block text-sm font-medium text-gray-700 mb-2">装饰音</label>
        <div class="flex flex-wrap gap-2">
          <button
            v-for="orn in ornaments"
            :key="orn.value"
            :class="[
              'px-2 py-1 text-sm rounded border',
              selectedOrnaments.includes(orn.value)
                ? 'border-purple-500 bg-purple-50 text-purple-700'
                : 'border-gray-200 hover:bg-gray-50'
            ]"
            @click="toggleOrnament(orn.value)"
          >
            {{ orn.symbol }} {{ orn.label }}
          </button>
        </div>
      </div>
    </div>
    
    <!-- 操作按钮 -->
    <div class="mt-6 pt-4 border-t flex space-x-2">
      <button
        @click="applyChanges"
        class="flex-1 px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600 transition"
      >
        应用更改
      </button>
      <button
        @click="resetChanges"
        class="px-4 py-2 bg-gray-200 text-gray-700 rounded hover:bg-gray-300 transition"
      >
        重置
      </button>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, watch } from 'vue'
import type { Note } from '@/types/score'

const props = defineProps<{
  note?: Note | null
}>()

const emit = defineEmits<{
  (e: 'change', note: Partial<Note>): void
  (e: 'apply'): void
  (e: 'reset'): void
}>()

// 音符类型配置
const noteTypes = [
  { value: 'whole', label: '全音符', shortLabel: '全', symbol: '𝅝' },
  { value: 'half', label: '二分音符', shortLabel: '½', symbol: '𝅗𝅥' },
  { value: 'quarter', label: '四分音符', shortLabel: '¼', symbol: '𝅘𝅥' },
  { value: 'eighth', label: '八分音符', shortLabel: '⅛', symbol: '𝅘𝅥𝅮' },
  { value: 'sixteenth', label: '十六分音符', shortLabel: '¹⁄₁₆', symbol: '𝅘𝅥𝅯' }
]

// 所有音高
const allPitches = [
  { name: 'C', octave: '大字一组', full: 'C2' },
  { name: 'D', octave: '大字一组', full: 'D2' },
  { name: 'E', octave: '大字一组', full: 'E2' },
  { name: 'F', octave: '大字一组', full: 'F2' },
  { name: 'G', octave: '大字一组', full: 'G2' },
  { name: 'A', octave: '大字一组', full: 'A2' },
  { name: 'B', octave: '大字一组', full: 'B2' },
  { name: 'C', octave: '大字组', full: 'C3' },
  { name: 'D', octave: '大字组', full: 'D3' },
  { name: 'E', octave: '大字组', full: 'E3' },
  { name: 'F', octave: '大字组', full: 'F3' },
  { name: 'G', octave: '大字组', full: 'G3' },
  { name: 'A', octave: '大字组', full: 'A3' },
  { name: 'B', octave: '大字组', full: 'B3' },
  { name: 'C', octave: '小字组', full: 'C4' },
  { name: 'D', octave: '小字组', full: 'D4' },
  { name: 'E', octave: '小字组', full: 'E4' },
  { name: 'F', octave: '小字组', full: 'F4' },
  { name: 'G', octave: '小字组', full: 'G4' },
  { name: 'A', octave: '小字组', full: 'A4' },
  { name: 'B', octave: '小字组', full: 'B4' },
  { name: 'C', octave: '小字一组', full: 'C5' },
  { name: 'D', octave: '小字一组', full: 'D5' },
  { name: 'E', octave: '小字一组', full: 'E5' },
  { name: 'F', octave: '小字一组', full: 'F5' },
  { name: 'G', octave: '小字一组', full: 'G5' },
  { name: 'A', octave: '小字一组', full: 'A5' },
  { name: 'B', octave: '小字一组', full: 'B5' }
]

// 快速时值选择
const quickDurations = [
  { value: 0.25, label: '十六分' },
  { value: 0.5, label: '八分' },
  { value: 1, label: '四分' },
  { value: 2, label: '二分' },
  { value: 4, label: '全音符' }
]

// 升降号选项
const accidentals = [
  { value: '', label: '无', symbol: '' },
  { value: 'sharp', label: '升号', symbol: '♯' },
  { value: 'flat', label: '降号', symbol: '♭' },
  { value: 'natural', label: '还原', symbol: '♮' }
]

// 装饰音选项
const ornaments = [
  { value: 'staccato', label: '断奏', symbol: '•' },
  { value: 'accent', label: '重音', symbol: '>' },
  { value: 'tenuto', label: '保持', symbol: '—' },
  { value: 'fermata', label: '延长', symbol: '𝄐' }
]

// 响应式状态
const selectedNoteType = ref(props.note?.type || 'quarter')
const selectedPitch = ref(
  allPitches.find(p => p.full === props.note?.pitch) || 
  { name: 'C', octave: '小字组', full: 'C4' }
)
const currentDuration = ref(props.note?.duration || 1)
const selectedAccidental = ref(props.note?.accidental || '')
const selectedOrnaments = ref<string[]>(props.note?.ornaments || [])
const showPitchSelector = ref(false)

// 计算属性
const durationDisplay = computed(() => {
  const dur = quickDurations.find(d => d.value === currentDuration.value)
  return dur ? dur.label : `${currentDuration.value}拍`
})

// 方法
const selectNoteType = (type: string) => {
  selectedNoteType.value = type
  emitChange()
}

const openPitchSelector = () => {
  showPitchSelector.value = !showPitchSelector.value
}

const selectPitch = (pitch: typeof allPitches[0]) => {
  selectedPitch.value = pitch
  showPitchSelector.value = false
  emitChange()
}

const increaseDuration = () => {
  if (currentDuration.value < 4) {
    currentDuration.value = Math.min(4, currentDuration.value + 0.25)
    emitChange()
  }
}

const decreaseDuration = () => {
  if (currentDuration.value > 0.25) {
    currentDuration.value = Math.max(0.25, currentDuration.value - 0.25)
    emitChange()
  }
}

const setDuration = (value: number) => {
  currentDuration.value = value
  emitChange()
}

const selectAccidental = (value: string) => {
  selectedAccidental.value = value
  emitChange()
}

const toggleOrnament = (value: string) => {
  const index = selectedOrnaments.value.indexOf(value)
  if (index > -1) {
    selectedOrnaments.value.splice(index, 1)
  } else {
    selectedOrnaments.value.push(value)
  }
  emitChange()
}

const emitChange = () => {
  emit('change', {
    type: selectedNoteType.value,
    pitch: selectedPitch.value.full,
    duration: currentDuration.value,
    accidental: selectedAccidental.value,
    ornaments: [...selectedOrnaments.value]
  })
}

const applyChanges = () => {
  emit('apply')
}

const resetChanges = () => {
  if (props.note) {
    selectedNoteType.value = props.note.type || 'quarter'
    selectedPitch.value = allPitches.find(p => p.full === props.note?.pitch) || 
                         { name: 'C', octave: '小字组', full: 'C4' }
    currentDuration.value = props.note.duration || 1
    selectedAccidental.value = props.note.accidental || ''
    selectedOrnaments.value = props.note.ornaments || []
  }
  emit('reset')
}

// 监听外部note变化
watch(() => props.note, (newNote) => {
  if (newNote) {
    selectedNoteType.value = newNote.type || 'quarter'
    selectedPitch.value = allPitches.find(p => p.full === newNote.pitch) || 
                         { name: 'C', octave: '小字组', full: 'C4' }
    currentDuration.value = newNote.duration || 1
    selectedAccidental.value = newNote.accidental || ''
    selectedOrnaments.value = newNote.ornaments || []
  }
}, { deep: true })

// 点击外部关闭音高选择器
document.addEventListener('click', (e) => {
  const target = e.target as HTMLElement
  if (!target.closest('.note-editor')) {
    showPitchSelector.value = false
  }
})
</script>

<style scoped>
.note-editor {
  min-width: 300px;
}
</style>