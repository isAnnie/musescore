<template>
  <div
    ref="noteElement"
    :class="[
      'draggable-note',
      note.isSelected ? 'selected' : '',
      isDragging ? 'dragging' : ''
    ]"
    :style="{
      left: note.position.x + 'px',
      top: note.position.y + 'px',
      zIndex: isDragging ? 1000 : 1
    }"
    @mousedown="startDrag"
    @touchstart="startDrag"
    @click="selectNote"
  >
    <!-- 音符可视化 -->
    <div class="note-visual">
      <div class="note-head" :class="noteHeadClass">
        {{ noteSymbol }}
      </div>
      <div 
        v-if="hasStem"
        class="note-stem"
        :class="stemDirection"
      ></div>
      <div 
        v-if="hasFlag"
        class="note-flag"
        :class="stemDirection"
      >
        {{ flagSymbol }}
      </div>
      <div 
        v-if="note.accidental"
        class="accidental"
      >
        {{ accidentalSymbol }}
      </div>
    </div>
    
    <!-- 装饰音标记 -->
    <div v-if="note.ornaments && note.ornaments.length > 0" class="ornaments">
      <span 
        v-for="ornament in note.ornaments" 
        :key="ornament"
        class="ornament-symbol"
      >
        {{ getOrnamentSymbol(ornament) }}
      </span>
    </div>
    
    <!-- 选择指示器 -->
    <div v-if="note.isSelected" class="selection-indicator"></div>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted, onUnmounted } from 'vue'
import type { Note } from '@/types/score'

const props = defineProps<{
  note: Note
}>()

const emit = defineEmits<{
  (e: 'select', note: Note): void
  (e: 'move', noteId: string, newPosition: { x: number; y: number }): void
  (e: 'drag-start', note: Note): void
  (e: 'drag-end', note: Note): void
}>()

const noteElement = ref<HTMLElement>()
const isDragging = ref(false)
const dragOffset = ref({ x: 0, y: 0 })

// 计算属性
const noteHeadClass = computed(() => {
  return `note-${props.note.type}`
})

const noteSymbol = computed(() => {
  const symbols: Record<string, string> = {
    whole: '𝅝',
    half: '𝅗𝅥',
    quarter: '𝅘𝅥',
    eighth: '𝅘𝅥𝅮',
    sixteenth: '𝅘𝅥𝅯'
  }
  return symbols[props.note.type] || '𝅘𝅥'
})

const hasStem = computed(() => {
  return props.note.type !== 'whole'
})

const hasFlag = computed(() => {
  return props.note.type === 'eighth' || props.note.type === 'sixteenth'
})

const stemDirection = computed(() => {
  return props.note.stemDirection || 'up'
})

const flagSymbol = computed(() => {
  return props.note.type === 'sixteenth' ? '𝅘𝅥𝅯' : '𝅘𝅥𝅮'
})

const accidentalSymbol = computed(() => {
  const symbols: Record<string, string> = {
    sharp: '♯',
    flat: '♭',
    natural: '♮'
  }
  return symbols[props.note.accidental || ''] || ''
})

// 方法
const getOrnamentSymbol = (ornament: string) => {
  const symbols: Record<string, string> = {
    staccato: '•',
    accent: '>',
    tenuto: '—',
    fermata: '𝄐'
  }
  return symbols[ornament] || ornament
}

const selectNote = (event: MouseEvent) => {
  event.stopPropagation()
  emit('select', props.note)
}

const startDrag = (event: MouseEvent | TouchEvent) => {
  event.preventDefault()
  event.stopPropagation()
  
  if (!noteElement.value) return
  
  isDragging.value = true
  emit('drag-start', props.note)
  
  const clientX = 'touches' in event ? event.touches[0].clientX : event.clientX
  const clientY = 'touches' in event ? event.touches[0].clientY : event.clientY
  
  const rect = noteElement.value.getBoundingClientRect()
  dragOffset.value = {
    x: clientX - rect.left,
    y: clientY - rect.top
  }
  
  document.addEventListener('mousemove', handleDrag)
  document.addEventListener('touchmove', handleDrag, { passive: false })
  document.addEventListener('mouseup', stopDrag)
  document.addEventListener('touchend', stopDrag)
}

const handleDrag = (event: MouseEvent | TouchEvent) => {
  if (!isDragging.value) return
  
  event.preventDefault()
  
  const clientX = 'touches' in event ? event.touches[0].clientX : event.clientX
  const clientY = 'touches' in event ? event.touches[0].clientY : event.clientY
  
  const container = noteElement.value?.parentElement
  if (!container) return
  
  const containerRect = container.getBoundingClientRect()
  const newX = clientX - containerRect.left - dragOffset.value.x
  const newY = clientY - containerRect.top - dragOffset.value.y
  
  // 边界检查
  const maxX = containerRect.width - (noteElement.value?.offsetWidth || 0)
  const maxY = containerRect.height - (noteElement.value?.offsetHeight || 0)
  
  const boundedX = Math.max(0, Math.min(maxX, newX))
  const boundedY = Math.max(0, Math.min(maxY, newY))
  
  emit('move', props.note.id, { x: boundedX, y: boundedY })
}

const stopDrag = () => {
  isDragging.value = false
  emit('drag-end', props.note)
  
  document.removeEventListener('mousemove', handleDrag)
  document.removeEventListener('touchmove', handleDrag)
  document.removeEventListener('mouseup', stopDrag)
  document.removeEventListener('touchend', stopDrag)
}

// 生命周期
onMounted(() => {
  // 可以在这里添加键盘事件监听等
})

onUnmounted(() => {
  // 清理事件监听
  document.removeEventListener('mousemove', handleDrag)
  document.removeEventListener('touchmove', handleDrag)
  document.removeEventListener('mouseup', stopDrag)
  document.removeEventListener('touchend', stopDrag)
})
</script>

<style scoped>
.draggable-note {
  position: absolute;
  cursor: grab;
  user-select: none;
  transition: transform 0.1s ease;
}

.draggable-note:hover {
  transform: scale(1.05);
}

.draggable-note.selected {
  outline: 2px solid #3b82f6;
  outline-offset: 2px;
  border-radius: 4px;
}

.draggable-note.dragging {
  cursor: grabbing;
  z-index: 1000;
  transform: rotate(5deg);
}

.note-visual {
  position: relative;
  display: flex;
  align-items: center;
  padding: 2px;
}

.note-head {
  font-size: 24px;
  line-height: 1;
}

.note-whole {
  color: #000;
}

.note-half {
  color: #000;
}

.note-quarter {
  color: #000;
}

.note-eighth {
  color: #000;
}

.note-sixteenth {
  color: #000;
}

.note-stem {
  width: 2px;
  height: 35px;
  background-color: #000;
  position: absolute;
}

.note-stem.up {
  top: -35px;
  right: 2px;
}

.note-stem.down {
  bottom: -35px;
  left: 2px;
}

.note-flag {
  position: absolute;
  font-size: 16px;
  line-height: 1;
}

.note-flag.up {
  top: -35px;
  right: 0;
}

.note-flag.down {
  bottom: -35px;
  left: 0;
  transform: scaleY(-1);
}

.accidental {
  position: absolute;
  left: -20px;
  top: 50%;
  transform: translateY(-50%);
  font-size: 20px;
  color: #000;
}

.ornaments {
  position: absolute;
  top: -25px;
  left: 50%;
  transform: translateX(-50%);
  display: flex;
  gap: 2px;
  font-size: 16px;
}

.ornament-symbol {
  color: #dc2626;
  font-weight: bold;
}

.selection-indicator {
  position: absolute;
  top: -5px;
  left: -5px;
  right: -5px;
  bottom: -5px;
  border: 2px dashed #3b82f6;
  border-radius: 6px;
  pointer-events: none;
}
</style>