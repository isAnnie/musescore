<template>
  <div class="editor-page">
    <!-- 加载状态 -->
    <div v-if="loading" class="loading-container">
      <div class="loading-content">
        <div class="loading-spinner"></div>
        <div class="loading-text">加载乐谱中...</div>
      </div>
    </div>

    <!-- 错误状态 -->
    <div v-else-if="error" class="error-container">
      <div class="error-content">
        <div class="error-icon">🎵</div>
        <h3 class="error-title">乐谱加载失败</h3>
        <p class="error-message">{{ error }}</p>
        
        <div class="error-actions">
          <!-- <button @click="retryLoading" class="error-btn primary">🔄 重试加载</button> -->
          <button @click="createBlankScore" class="error-btn secondary">📝 创建新乐谱</button>
          <router-link to="/" class="error-btn link">🏠 返回首页</router-link>
        </div>
        
        <div class="error-help" v-if="error.includes('未找到')">
          <h4>💡 可能的解决方案：</h4>
          <ul>
            <li>检查网址是否正确</li>
            <li>乐谱可能已被删除</li>
            <li>尝试创建新的乐谱</li>
            <li>从首页重新选择乐谱</li>
          </ul>
        </div>
      </div>
    </div>

    <!-- 编辑器主界面 -->
    <div v-else class="editor-container">
      <!-- 乐谱编辑器 -->
      <!-- <FullScoreEditor
        v-if="currentScore"
        :key="scoreKey"
        :score="currentScore"
        @save="handleSave"
        @export="handleExport"
        @close="handleClose"
      /> -->
      
      <!-- 使用简化的ScoreCanvas组件 -->
      <SimpleScoreCanvas 
        v-if="currentScore"
        :score="currentScore"
      />
      
      <!-- 空状态（新建乐谱） -->
      <div v-else class="empty-editor">
        <div class="empty-content">
          <div class="empty-icon">🎵</div>
          <h3 class="empty-title">创建新乐谱</h3>
          <p class="empty-description">开始创作您的音乐作品</p>
          
          <div class="quick-start-options">
            <div class="quick-start-card" @click="createBlankScore">
              <div class="card-icon">📄</div>
              <h4 class="card-title">空白乐谱</h4>
              <p class="card-desc">从零开始创建</p>
            </div>
            
            <div class="quick-start-card" @click="importFromFile">
              <div class="card-icon">📥</div>
              <h4 class="card-title">导入文件</h4>
              <p class="card-desc">MIDI, MusicXML</p>
            </div>
            
            <div class="quick-start-card" @click="useTemplate">
              <div class="card-icon">🎨</div>
              <h4 class="card-title">使用模板</h4>
              <p class="card-desc">快速开始</p>
            </div>
            
            <div class="quick-start-card" @click="openRecentScores">
              <div class="card-icon">⏰</div>
              <h4 class="card-title">最近编辑</h4>
              <p class="card-desc">继续创作</p>
            </div>
          </div>
          
          <!-- 节日特辑 -->
          <div v-if="showFestivalSection" class="festival-section">
            <div class="festival-header">
              <div class="festival-icon">🎆</div>
              <h4 class="festival-title">新春特辑</h4>
            </div>
            <div class="festival-options">
              <button class="festival-btn" @click="createFestivalScore('马年新春')">
                <span class="btn-icon">🐎</span>
                <span>马年主题音乐</span>
              </button>
              <button class="festival-btn" @click="createFestivalScore('春节序曲')">
                <span class="btn-icon">🎶</span>
                <span>春节传统音乐</span>
              </button>
              <button class="festival-btn" @click="joinFestivalContest">
                <span class="btn-icon">🏆</span>
                <span>新春创作大赛</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- 模板选择模态框 -->
    <!-- <TemplateModal
      v-if="showTemplateModal"
      @close="showTemplateModal = false"
      @select="applyTemplate"
    /> -->

    <!-- 文件导入模态框 -->
    <!-- <ImportModal
      v-if="showImportModal"
      @close="showImportModal = false"
      @import="handleFileImport"
    /> -->

    <!-- 最近乐谱抽屉 -->
    <!-- <RecentScoresDrawer
      v-if="showRecentDrawer"
      @close="showRecentDrawer = false"
      @select="loadSelectedScore"
    /> -->

    <!-- 保存提示模态框 -->
    <!-- <SavePromptModal
      v-if="showSavePrompt"
      :score-title="currentScore?.title || '未命名乐谱'"
      @save="confirmSave"
      @dont-save="discardChanges"
      @cancel="cancelClose"
    /> -->
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted, onBeforeUnmount, watch, onUnmounted } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { useScoreStore } from '@/stores/scoreStore'
import { useUserStore } from '@/stores/userStore'
// 暂时注释掉缺失的组件
// import FullScoreEditor from '@/components/editor/FullScoreEditor.vue'
// import TemplateModal from '@/components/modals/TemplateModal.vue'
// import ImportModal from '@/components/modals/ImportModal.vue'
// import RecentScoresDrawer from '@/components/drawers/RecentScoresDrawer.vue'
// import SavePromptModal from '@/components/modals/SavePromptModal.vue'
import ScoreCanvas from '@/components/editor/ScoreCanvas.vue'
import SimpleScoreCanvas from '@/components/editor/SimpleScoreCanvas.vue'
import type { Score } from '@/types/score'

const route = useRoute()
const router = useRouter()
const scoreStore = useScoreStore()
const userStore = useUserStore()

// 页面状态
const loading = ref(false)
const error = ref<string | null>(null)
const scoreKey = ref(Date.now()) // 用于强制重新渲染编辑器
const hasUnsavedChanges = ref(false)

// 模态框状态
const showTemplateModal = ref(false)
const showImportModal = ref(false)
const showRecentDrawer = ref(false)
const showSavePrompt = ref(false)

// 计算属性
const currentScore = computed(() => scoreStore.currentScore)
const scoreId = computed(() => route.params.id as string)

// 判断是否显示节日特辑
const showFestivalSection = computed(() => {
  const now = new Date()
  const newYearStart = new Date('2026-02-17')
  const newYearEnd = new Date('2026-03-03')
  return now >= newYearStart && now <= newYearEnd
})

// 生命周期
onMounted(() => {
  // 恢复本地存储的乐谱数据
  restoreScoresFromLocalStorage()
  
  // 加载乐谱
  if (scoreId.value) {
    loadScore(scoreId.value)
  }
  
  // 添加路由守卫提示
  window.addEventListener('beforeunload', handleBeforeUnload)
  
  // 监听 store 变化并自动保存
  const unwatch = watch(
    () => scoreStore.scores,
    () => {
      saveScoresToLocalStorage()
    },
    { deep: true }
  )
  
  onUnmounted(() => {
    unwatch()
  })
})

onBeforeUnmount(() => {
  window.removeEventListener('beforeunload', handleBeforeUnload)
})

// 离开页面提示
const handleBeforeUnload = (e: BeforeUnloadEvent) => {
  if (hasUnsavedChanges.value) {
    e.preventDefault()
    e.returnValue = '您有未保存的更改，确定要离开吗？'
  }
}

// 监听路由变化
watch(
  () => route.params.id,
  (newId) => {
    if (newId) {
      loadScore(newId as string)
    } else {
      scoreStore.currentScore = null
    }
  }
)

// 加载乐谱
const loadScore = async (id: string) => {
  loading.value = true
  error.value = null
  
  try {
    console.log('尝试加载乐谱 ID:', id)
    
    // 首先检查 store 中是否已有该乐谱
    let score = scoreStore.scores.find(s => s.id === id)
    
    if (score) {
      console.log('从 store 找到乐谱')
      scoreStore.currentScore = score
      scoreKey.value = Date.now()
    } else {
      console.log('store 中未找到乐谱，尝试从本地存储恢复')
      
      // 尝试从本地存储恢复
      const savedScores = localStorage.getItem('musescore-scores')
      if (savedScores) {
        try {
          const scores = JSON.parse(savedScores)
          score = scores.find((s: any) => s.id === id)
          
          if (score) {
            console.log('从本地存储恢复乐谱')
            // 添加到 store
            scoreStore.scores.push(score)
            scoreStore.currentScore = score
            scoreKey.value = Date.now()
          } else {
            throw new Error('本地存储中也未找到该乐谱')
          }
        } catch (parseError) {
          console.error('解析本地存储失败:', parseError)
          throw new Error('乐谱数据损坏')
        }
      } else {
        throw new Error('未找到该乐谱')
      }
    }
  } catch (err) {
    console.error('加载乐谱失败:', err)
    const errorMessage = err instanceof Error ? err.message : '加载乐谱时发生错误'
    error.value = errorMessage
    
    // 提供更多帮助信息
    if (errorMessage.includes('未找到')) {
      error.value += '。您可以：'
    }
  } finally {
    loading.value = false
  }
}

// 保存乐谱到本地存储
const saveScoresToLocalStorage = () => {
  try {
    const scoresToSave = scoreStore.scores.map(score => ({
      ...score,
      createdAt: score.createdAt instanceof Date ? score.createdAt.toISOString() : score.createdAt,
      updatedAt: score.updatedAt instanceof Date ? score.updatedAt.toISOString() : score.updatedAt
    }))
    
    localStorage.setItem('musescore-scores', JSON.stringify(scoresToSave))
    console.log('乐谱已保存到本地存储')
  } catch (error) {
    console.error('保存到本地存储失败:', error)
  }
}

// 从本地存储恢复乐谱
const restoreScoresFromLocalStorage = () => {
  try {
    const savedScores = localStorage.getItem('musescore-scores')
    if (savedScores) {
      const scores = JSON.parse(savedScores)
      // 转换日期字符串为 Date 对象
      const parsedScores = scores.map((score: any) => ({
        ...score,
        createdAt: new Date(score.createdAt),
        updatedAt: new Date(score.updatedAt)
      }))
      
      // 合并到现有 scores 中（避免重复）
      parsedScores.forEach((score: any) => {
        if (!scoreStore.scores.some(s => s.id === score.id)) {
          scoreStore.scores.push(score)
        }
      })
      
      console.log(`从本地存储恢复了 ${parsedScores.length} 个乐谱`)
    }
  } catch (error) {
    console.error('从本地存储恢复失败:', error)
  }
}

// 创建空白乐谱
const createBlankScore = () => {
  const newScore: Score = {
    id: Date.now().toString(),
    title: '未命名乐谱',
    composer: userStore.user?.username || '',
    tempo: 120,
    timeSignature: { numerator: 4, denominator: 4 },
    keySignature: 'C',
    notes: [
      // 添加一些示例音符用于测试
      {
        id: 'test-1',
        type: 'quarter',
        pitch: 'C4',
        duration: 1,
        position: { x: 100, y: 150 }
      },
      {
        id: 'test-2',
        type: 'quarter',
        pitch: 'D4',
        duration: 1,
        position: { x: 150, y: 150 }
      },
      {
        id: 'test-3',
        type: 'quarter',
        pitch: 'E4',
        duration: 1,
        position: { x: 200, y: 150 }
      }
    ],
    measures: [],
    createdAt: new Date(),
    updatedAt: new Date(),
    isDraft: true
  }
  
  const createdScore = scoreStore.createScore(newScore)
  navigateToScore(createdScore.id)
}

// 创建节日主题乐谱
const createFestivalScore = (title: string) => {
  const newScore: Score = {
    id: Date.now().toString(),
    title,
    composer: userStore.user?.username || '',
    tempo: 100,
    timeSignature: { numerator: 4, denominator: 4 },
    keySignature: 'F',
    notes: [
      {
        id: '1',
        type: 'quarter',
        pitch: 'C4',
        duration: 1,
        position: { x: 100, y: 150 }
      },
      {
        id: '2',
        type: 'quarter',
        pitch: 'D4',
        duration: 1,
        position: { x: 150, y: 150 }
      },
      {
        id: '3',
        type: 'quarter',
        pitch: 'E4',
        duration: 1,
        position: { x: 200, y: 150 }
      },
      {
        id: '4',
        type: 'quarter',
        pitch: 'F4',
        duration: 1,
        position: { x: 250, y: 150 }
      }
    ],
    measures: [],
    createdAt: new Date(),
    updatedAt: new Date(),
    isDraft: true,
    tags: ['春节', '马年', '节日']
  }
  
  const createdScore = scoreStore.createScore(newScore)
  navigateToScore(createdScore.id)
}

// 导入文件
const importFromFile = () => {
  showImportModal.value = true
}

// 处理文件导入
const handleFileImport = async (file: File) => {
  try {
    loading.value = true
    const importedScore = await scoreStore.importMIDI(file)
    navigateToScore(importedScore.id)
  } catch (err) {
    console.error('导入失败:', err)
    error.value = '导入文件时发生错误'
  } finally {
    loading.value = false
  }
}

// 使用模板
const useTemplate = () => {
  showTemplateModal.value = true
}

// 应用模板
const applyTemplate = (template: any) => {
  const newScore: Score = {
    id: Date.now().toString(),
    title: template.name,
    composer: userStore.user?.username || '',
    tempo: template.tempo || 120,
    timeSignature: template.timeSignature || { numerator: 4, denominator: 4 },
    keySignature: template.keySignature || 'C',
    notes: template.notes || [],
    measures: [],
    createdAt: new Date(),
    updatedAt: new Date(),
    isDraft: true
  }
  
  const createdScore = scoreStore.createScore(newScore)
  navigateToScore(createdScore.id)
  showTemplateModal.value = false
}

// 打开最近乐谱
const openRecentScores = () => {
  showRecentDrawer.value = true
}

// 加载选中的乐谱
const loadSelectedScore = (scoreId: string) => {
  navigateToScore(scoreId)
  showRecentDrawer.value = false
}

// 参加新春创作大赛
const joinFestivalContest = () => {
  router.push('/contests/festival')
}

// 保存处理
const handleSave = () => {
  if (currentScore.value) {
    // 更新时间戳
    currentScore.value.updatedAt = new Date()
    currentScore.value.isDraft = false
    hasUnsavedChanges.value = false
    
    // 保存到本地存储
    saveScoresToLocalStorage()
    
    // 在实际应用中，这里会调用API保存到服务器
    console.log('保存乐谱:', currentScore.value)
    
    // 显示保存成功提示
    showSaveSuccess()
  }
}

// 导出处理
const handleExport = (format: string) => {
  if (!currentScore.value) return
  
  switch (format) {
    case 'midi':
      exportMIDI(currentScore.value)
      break
    case 'pdf':
      exportPDF(currentScore.value)
      break
    case 'musicxml':
      exportMusicXML(currentScore.value)
      break
  }
}

// 导出MIDI
const exportMIDI = (score: Score) => {
  const midiBlob = scoreStore.exportToMIDI(score)
  const url = URL.createObjectURL(midiBlob)
  const a = document.createElement('a')
  a.href = url
  a.download = `${score.title}.mid`
  document.body.appendChild(a)
  a.click()
  document.body.removeChild(a)
  URL.revokeObjectURL(url)
}

// 导出PDF
const exportPDF = (score: Score) => {
  // 这里可以集成PDF生成库
  console.log('导出PDF:', score)
  alert('PDF导出功能开发中...')
}

// 导出MusicXML
const exportMusicXML = (score: Score) => {
  const xmlContent = scoreStore.exportToMusicXML(score)
  const blob = new Blob([xmlContent], { type: 'application/xml' })
  const url = URL.createObjectURL(blob)
  const a = document.createElement('a')
  a.href = url
  a.download = `${score.title}.musicxml`
  document.body.appendChild(a)
  a.click()
  document.body.removeChild(a)
  URL.revokeObjectURL(url)
}

// 关闭编辑器
const handleClose = () => {
  if (hasUnsavedChanges.value) {
    showSavePrompt.value = true
  } else {
    router.push('/')
  }
}

// 确认保存
const confirmSave = () => {
  handleSave()
  showSavePrompt.value = false
  router.push('/')
}

// 不保存
const discardChanges = () => {
  hasUnsavedChanges.value = false
  showSavePrompt.value = false
  router.push('/')
}

// 取消关闭
const cancelClose = () => {
  showSavePrompt.value = false
}

// 导航到乐谱
const navigateToScore = (id: string) => {
  router.push(`/editor/${id}`)
}

// 显示保存成功提示
const showSaveSuccess = () => {
  const successEl = document.createElement('div')
  successEl.className = 'save-success-toast'
  successEl.textContent = '✓ 保存成功'
  document.body.appendChild(successEl)
  
  setTimeout(() => {
    successEl.classList.add('show')
  }, 10)
  
  setTimeout(() => {
    successEl.classList.remove('show')
    setTimeout(() => {
      document.body.removeChild(successEl)
    }, 300)
  }, 2000)
}
</script>

<style scoped>
.editor-page {
  @apply h-full;
}

/* 加载状态 */
.loading-container {
  @apply flex items-center justify-center h-full bg-gray-50;
}

.loading-content {
  @apply flex flex-col items-center;
}

.loading-spinner {
  @apply w-12 h-12 border-4 border-blue-500 border-t-transparent 
         rounded-full animate-spin;
}

.loading-text {
  @apply mt-4 text-gray-600;
}

/* 错误状态 */
.error-container {
  @apply flex items-center justify-center h-full bg-gradient-to-br from-blue-50 to-indigo-100;
}

.error-content {
  @apply text-center max-w-md p-8 bg-white rounded-2xl shadow-xl;
}

.error-icon {
  @apply text-6xl mb-4;
}

.error-title {
  @apply text-2xl font-bold text-gray-800 mb-3;
}

.error-message {
  @apply text-gray-600 mb-6 leading-relaxed;
}

.error-actions {
  @apply flex flex-col sm:flex-row gap-3 justify-center mb-6;
}

.error-btn {
  @apply px-6 py-3 rounded-lg font-medium transition-all duration-200;
}

.error-btn.primary {
  @apply bg-blue-500 text-white hover:bg-blue-600 shadow-md hover:shadow-lg;
}

.error-btn.secondary {
  @apply bg-green-500 text-white hover:bg-green-600 shadow-md hover:shadow-lg;
}

.error-btn.link {
  @apply bg-gray-100 text-gray-700 hover:bg-gray-200 border border-gray-300;
}

.error-help {
  @apply bg-blue-50 border border-blue-200 rounded-lg p-4 text-left;
}

.error-help h4 {
  @apply text-blue-800 font-semibold mb-2;
}

.error-help ul {
  @apply text-blue-700 text-sm space-y-1;
}

.error-help li {
  @apply flex items-start;
}

.error-help li:before {
  @apply content-['•'] text-blue-500 font-bold mr-2;
}

/* 空状态 */
.empty-editor {
  @apply flex items-center justify-center h-full bg-gray-50 p-8;
}

.empty-content {
  @apply text-center max-w-4xl;
}

.empty-icon {
  @apply text-8xl mb-6;
}

.empty-title {
  @apply text-3xl font-bold text-gray-800 mb-2;
}

.empty-description {
  @apply text-gray-600 text-lg mb-8;
}

/* 快速开始选项 */
.quick-start-options {
  @apply grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-12;
}

.quick-start-card {
  @apply p-6 bg-white rounded-xl border border-gray-200 
         hover:border-blue-300 hover:shadow-lg transition-all 
         cursor-pointer;
}

.quick-start-card:hover .card-icon {
  @apply transform scale-110;
}

.card-icon {
  @apply text-4xl mb-3 transition-transform;
}

.card-title {
  @apply text-lg font-semibold text-gray-800 mb-1;
}

.card-desc {
  @apply text-sm text-gray-600;
}

/* 节日特辑 */
.festival-section {
  @apply bg-gradient-to-r from-yellow-50 to-orange-50 border 
         border-yellow-200 rounded-xl p-6;
}

.festival-header {
  @apply flex items-center justify-center mb-4;
}

.festival-icon {
  @apply text-3xl mr-3;
}

.festival-title {
  @apply text-xl font-semibold text-yellow-800;
}

.festival-options {
  @apply flex flex-wrap justify-center gap-3;
}

.festival-btn {
  @apply flex items-center space-x-2 px-4 py-2 bg-white border 
         border-yellow-300 rounded-lg hover:bg-yellow-50 
         transition-colors;
}

.btn-icon {
  @apply text-xl;
}

/* 编辑器容器 */
.editor-container {
  @apply h-full bg-gray-50;
}

/* 保存成功提示样式 */
:deep(.save-success-toast) {
  @apply fixed top-4 right-4 bg-green-500 text-white px-4 py-2 
         rounded-lg shadow-lg transform translate-x-full 
         transition-transform duration-300 z-50;
}

:deep(.save-success-toast.show) {
  @apply translate-x-0;
}
</style>