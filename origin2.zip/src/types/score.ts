export interface Note {
  id: string
  type: 'whole' | 'half' | 'quarter' | 'eighth' | 'sixteenth'
  pitch: string // 如 'C4', 'D5'
  duration: number
  position: { x: number; y: number }
  accidental?: 'sharp' | 'flat' | 'natural'
  ornaments?: string[] // 装饰音: staccato, accent, tenuto, fermata
  dynamics?: string // 力度记号: pp, p, mp, mf, f, ff
  articulation?: string // 发音记号
  lyrics?: string // 歌词
  stemDirection?: 'up' | 'down' | 'auto' // 符干方向
  beamGroup?: string // 连音组ID
  isSelected?: boolean // 是否被选中
}

export interface TimeSignature {
  numerator: number
  denominator: number
}

export interface Score {
  id: string
  title: string
  composer: string
  tempo: number
  timeSignature: TimeSignature
  keySignature: string
  notes: Note[]
  createdAt: Date
  updatedAt: Date
}

export interface User {
  id: string
  username: string
  email: string
  avatar?: string
  scores: Score[]
}