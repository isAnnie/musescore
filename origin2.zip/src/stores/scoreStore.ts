import { defineStore } from 'pinia'
import { ref, computed } from 'vue'
import type { Score, Note } from '@/types/score'

export const useScoreStore = defineStore('score', () => {
  const currentScore = ref<Score | null>(null)
  const scores = ref<Score[]>([
    {
      id: '1',
      title: '新春序曲',
      composer: '传统音乐',
      tempo: 120,
      timeSignature: { numerator: 4, denominator: 4 },
      keySignature: 'C',
      notes: [
        {
          id: 'test-1',
          type: 'quarter',
          pitch: 'C4',
          duration: 1,
          position: { x: 100, y: 150 }
        },
        {
          id: 'test-2',
          type: 'quarter',
          pitch: 'D4',
          duration: 1,
          position: { x: 150, y: 150 }
        }
      ],
      createdAt: new Date('2026-02-17'),
      updatedAt: new Date('2026-02-20')
    },
    {
      id: '2',
      title: '马年吉祥',
      composer: '现代编曲',
      tempo: 100,
      timeSignature: { numerator: 3, denominator: 4 },
      keySignature: 'G',
      notes: [],
      createdAt: new Date('2026-02-18'),
      updatedAt: new Date()
    }
  ])

  const addNote = (note: Note) => {
    if (currentScore.value) {
      currentScore.value.notes.push(note)
      currentScore.value.updatedAt = new Date()
    }
  }

  const removeNote = (noteId: string) => {
    if (currentScore.value) {
      currentScore.value.notes = currentScore.value.notes.filter(
        note => note.id !== noteId
      )
      currentScore.value.updatedAt = new Date()
    }
  }

  const createScore = (title: string) => {
    const newScore: Score = {
      id: Date.now().toString(),
      title,
      composer: '未命名作曲家',
      tempo: 120,
      timeSignature: { numerator: 4, denominator: 4 },
      keySignature: 'C',
      notes: [],
      createdAt: new Date(),
      updatedAt: new Date()
    }
    scores.value.push(newScore)
    return newScore
  }

  const recentScores = computed(() => {
    return [...scores.value]
      .sort((a, b) => b.updatedAt.getTime() - a.updatedAt.getTime())
      .slice(0, 5)
  })

  return {
    currentScore,
    scores,
    recentScores,
    addNote,
    removeNote,
    createScore
  }
})