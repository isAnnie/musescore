import { createRouter, createWebHistory } from 'vue-router'
import MainLayout from '@/layouts/MainLayout.vue'
import { authGuard, saveEditorState, trackPageView } from './guards'

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    {
      path: '/',
      component: MainLayout,
      children: [
        {
          path: '',
          name: 'home',
          component: () => import('@/pages/HomePage.vue')
        },
        {
          path: '/editor/:id?',
          name: 'editor',
          component: () => import('@/pages/EditorPage.vue')
        },
        {
          path: '/browse',
          name: 'browse',
          component: () => import('@/pages/BrowsePage.vue')
        },
        {
          path: '/profile',
          name: 'profile',
          component: () => import('@/pages/ProfilePage.vue')
        }
      ]
    },
    // 404页面处理
    {
      path: '/:pathMatch(.*)*',
      name: 'not-found',
      component: () => import('@/pages/NotFoundPage.vue')
    }
  ],
  scrollBehavior: trackPageView
})

// 应用路由守卫
router.beforeEach(authGuard)
router.beforeEach(saveEditorState)
router.afterEach(trackPageView)

export default router