import { defineStore } from 'pinia'
import { ref, computed } from 'vue'
import type { User } from '@/types/score'

export const useUserStore = defineStore('user', () => {
  const user = ref<User | null>(null)
  const token = ref<string | null>(localStorage.getItem('token'))

  const isLoggedIn = computed(() => !!token.value)

  // 模拟登录
  const login = async (username: string, password: string) => {
    // 实际项目中这里应该是API调用
    return new Promise((resolve) => {
      setTimeout(() => {
        user.value = {
          id: '1',
          username,
          email: `${username}@example.com`,
          scores: []
        }
        token.value = 'mock-token'
        localStorage.setItem('token', token.value)
        resolve(true)
      }, 1000)
    })
  }

  // 登出
  const logout = () => {
    user.value = null
    token.value = null
    localStorage.removeItem('token')
  }

  // 检查登录状态
  const checkAuth = () => {
    if (token.value && !user.value) {
      // 模拟从token恢复用户信息
      user.value = {
        id: '1',
        username: 'musiclover',
        email: 'musiclover@example.com',
        scores: []
      }
    }
  }

  // 更新用户信息
  const updateUser = (updates: Partial<User>) => {
    if (user.value) {
      user.value = { ...user.value, ...updates }
    }
  }

  return {
    user,
    token,
    isLoggedIn,
    login,
    logout,
    checkAuth,
    updateUser
  }
})