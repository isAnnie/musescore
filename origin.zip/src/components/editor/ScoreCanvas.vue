<template>
  <div class="score-editor h-full flex flex-col">
    <!-- 顶部工具栏 -->
    <div class="editor-header bg-white border-b p-4">
      <div class="flex items-center justify-between">
        <div class="flex items-center space-x-4">
          <div class="text-lg font-semibold">
            {{ scoreTitle }}
            <input
              v-if="isEditingTitle"
              v-model="scoreTitle"
              @blur="saveTitle"
              @keyup.enter="saveTitle"
              class="ml-2 border px-2 py-1 rounded"
            />
            <button
              v-else
              @click="startEditingTitle"
              class="ml-2 text-blue-500 hover:text-blue-700"
            >
              编辑
            </button>
          </div>
          
          <div class="flex items-center space-x-2">
            <span class="text-sm text-gray-600">拍号:</span>
            <select v-model="timeSignature.numerator" class="border rounded px-2 py-1">
              <option v-for="n in [2, 3, 4, 6, 9, 12]" :key="n" :value="n">{{ n }}</option>
            </select>
            <span>/</span>
            <select v-model="timeSignature.denominator" class="border rounded px-2 py-1">
              <option v-for="d in [2, 4, 8, 16]" :key="d" :value="d">{{ d }}</option>
            </select>
          </div>
          
          <div class="flex items-center space-x-2">
            <span class="text-sm text-gray-600">调号:</span>
            <select v-model="keySignature" class="border rounded px-2 py-1">
              <option v-for="key in keySignatures" :key="key" :value="key">{{ key }}</option>
            </select>
          </div>
        </div>
        
        <div class="flex items-center space-x-3">
          <button
            class="px-4 py-2 bg-green-500 text-white rounded hover:bg-green-600 transition"
            @click="playComposition"
          >
            ▶️ 播放
          </button>
          <button
            class="px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600 transition"
            @click="saveScore"
          >
            💾 保存
          </button>
          <button
            class="px-4 py-2 bg-purple-500 text-white rounded hover:bg-purple-600 transition"
            @click="exportMidi"
          >
            📥 导出
          </button>
        </div>
      </div>
      
      <!-- 速度和节拍器控制 -->
      <div class="mt-4 flex items-center space-x-6">
        <div class="flex items-center space-x-2">
          <span class="text-sm text-gray-600">速度:</span>
          <input
            type="range"
            min="40"
            max="200"
            v-model="tempo"
            class="w-32"
          />
          <span class="w-12">{{ tempo }} BPM</span>
        </div>
        
        <div class="flex items-center space-x-2">
          <button
            :class="['px-3 py-1 rounded', metronomeOn ? 'bg-red-500 text-white' : 'bg-gray-200']"
            @click="toggleMetronome"
          >
            {{ metronomeOn ? '⏹️ 停止节拍器' : '🎵 启动节拍器' }}
          </button>
        </div>
      </div>
    </div>
    
    <!-- 主编辑区域 -->
    <div class="flex flex-1 overflow-hidden">
      <!-- 左侧工具面板 -->
      <div class="w-64 border-r bg-gray-50 p-4 overflow-y-auto">
        <MusicToolbar
          @note-selected="handleNoteSelected"
          @pitch-selected="handlePitchSelected"
        />
        
        <!-- 附加工具 -->
        <div class="mt-6 space-y-4">
          <h4 class="font-medium text-gray-700">附加工具</h4>
          
          <div class="space-y-2">
            <button
              class="w-full px-3 py-2 text-left border rounded hover:bg-gray-100 transition"
              @click="addRest"
            >
              🎵 添加休止符
            </button>
            <button
              class="w-full px-3 py-2 text-left border rounded hover:bg-gray-100 transition"
              @click="addChord"
            >
              🎹 添加和弦
            </button>
            <button
              class="w-full px-3 py-2 text-left border rounded hover:bg-gray-100 transition"
              @click="undoAction"
            >
              ↩️ 撤销
            </button>
            <button
              class="w-full px-3 py-2 text-left border rounded hover:bg-gray-100 transition"
              @click="redoAction"
            >
              ↪️ 重做
            </button>
          </div>
        </div>
      </div>
      
      <!-- 乐谱画布 -->
      <div class="flex-1 flex flex-col">
        <!-- 乐谱行号 -->
        <div class="border-b bg-gray-50 px-4 py-2">
          <div class="flex space-x-8 text-sm text-gray-600">
            <div v-for="i in 10" :key="i" class="w-16 text-center">
              第 {{ i }} 小节
            </div>
          </div>
        </div>
        
        <!-- 乐谱显示区域 -->
        <div
          ref="canvasContainer"
          class="flex-1 bg-white p-8 overflow-auto"
          @click="handleCanvasClick"
        >
          <div class="score-display-area" :style="{ minWidth: '800px', minHeight: '600px' }">
            <!-- 使用VexFlow绘制乐谱 -->
            <canvas ref="canvas"></canvas>
          </div>
        </div>
      </div>
      
      <!-- 右侧属性面板 -->
      <div class="w-64 border-l bg-gray-50 p-4 overflow-y-auto">
        <h4 class="font-medium text-gray-700 mb-4">属性</h4>
        
        <div v-if="selectedNote" class="space-y-4">
          <div class="border rounded-lg p-3 bg-white">
            <h5 class="font-medium mb-2">选中的音符</h5>
            <div class="space-y-2 text-sm">
              <div class="flex justify-between">
                <span class="text-gray-600">音高:</span>
                <span class="font-medium">{{ selectedNote.pitch }}</span>
              </div>
              <div class="flex justify-between">
                <span class="text-gray-600">类型:</span>
                <span class="font-medium">{{ selectedNote.type }}</span>
              </div>
              <div class="flex justify-between">
                <span class="text-gray-600">时长:</span>
                <span class="font-medium">{{ selectedNote.duration }}拍</span>
              </div>
              <div class="mt-3">
                <label class="block text-xs text-gray-600 mb-1">升降号:</label>
                <select
                  v-model="selectedNote.accidental"
                  class="w-full border rounded px-2 py-1 text-sm"
                >
                  <option value="">无</option>
                  <option value="sharp">♯ (升号)</option>
                  <option value="flat">♭ (降号)</option>
                  <option value="natural">♮ (还原)</option>
                </select>
              </div>
              <button
                @click="deleteSelectedNote"
                class="mt-3 w-full px-3 py-1 bg-red-500 text-white rounded hover:bg-red-600 text-sm"
              >
                删除音符
              </button>
            </div>
          </div>
        </div>
        
        <!-- 乐谱信息 -->
        <div class="mt-6 border rounded-lg p-3 bg-white">
          <h5 class="font-medium mb-2">乐谱信息</h5>
          <div class="space-y-2 text-sm">
            <div class="flex justify-between">
              <span class="text-gray-600">总音符数:</span>
              <span class="font-medium">{{ notes.length }}</span>
            </div>
            <div class="flex justify-between">
              <span class="text-gray-600">总时长:</span>
              <span class="font-medium">{{ totalDuration }}拍</span>
            </div>
            <div class="flex justify-between">
              <span class="text-gray-600">创建时间:</span>
              <span class="font-medium">{{ formatDate(createdAt) }}</span>
            </div>
            <div class="flex justify-between">
              <span class="text-gray-600">最后修改:</span>
              <span class="font-medium">{{ formatDate(updatedAt) }}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
    
    <!-- 底部状态栏 -->
    <div class="border-t bg-gray-800 text-white px-4 py-2 text-sm">
      <div class="flex justify-between">
        <div>
          状态: <span class="text-green-400">已就绪</span> |
          当前工具: <span class="font-medium">{{ currentTool }}</span>
        </div>
        <div>
          位置: X={{ mouseX }}, Y={{ mouseY }} |
          缩放: {{ zoomLevel }}%
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted, watch, computed } from 'vue'
import { useRoute } from 'vue-router'
import dayjs from 'dayjs'
import { useScoreStore } from '@/stores/scoreStore'
import MusicToolbar from '@/components/common/MusicToolbar.vue'
import type { Note } from '@/types/score'

// 路由参数
const route = useRoute()
const scoreId = computed(() => route.params.id as string)

// 状态管理
const scoreStore = useScoreStore()
const currentScore = computed(() => scoreStore.currentScore)

// 响应式状态
const scoreTitle = ref('未命名乐谱')
const isEditingTitle = ref(false)
const timeSignature = ref({ numerator: 4, denominator: 4 })
const keySignature = ref('C')
const tempo = ref(120)
const metronomeOn = ref(false)
const selectedNote = ref<Note | null>(null)
const mouseX = ref(0)
const mouseY = ref(0)
const zoomLevel = ref(100)
const currentTool = ref('音符工具')

// 调号选项
const keySignatures = ['C', 'G', 'D', 'A', 'E', 'B', 'F#', 'C#', 'F', 'Bb', 'Eb', 'Ab', 'Db', 'Gb', 'Cb']

// 计算属性
const notes = computed(() => currentScore.value?.notes || [])
const totalDuration = computed(() => {
  return notes.value.reduce((total, note) => total + note.duration, 0)
})
const createdAt = computed(() => currentScore.value?.createdAt || new Date())
const updatedAt = computed(() => currentScore.value?.updatedAt || new Date())

// 画布引用
const canvas = ref<HTMLCanvasElement>()
const canvasContainer = ref<HTMLDivElement>()

// 方法
const handleNoteSelected = (type: string) => {
  currentTool.value = `${type}音符`
}

const handlePitchSelected = (pitch: string) => {
  if (selectedNote.value) {
    selectedNote.value.pitch = pitch
  }
}

const handleCanvasClick = (event: MouseEvent) => {
  if (!canvasContainer.value) return
  
  const rect = canvasContainer.value.getBoundingClientRect()
  mouseX.value = Math.round(event.clientX - rect.left)
  mouseY.value = Math.round(event.clientY - rect.top)
  
  // 创建新音符
  const note: Note = {
    id: Date.now().toString(),
    type: 'quarter', // 默认四分音符
    pitch: 'C4',
    duration: 1,
    position: { x: mouseX.value, y: mouseY.value }
  }
  
  scoreStore.addNote(note)
  selectedNote.value = note
}

const startEditingTitle = () => {
  isEditingTitle.value = true
}

const saveTitle = () => {
  isEditingTitle.value = false
  if (currentScore.value) {
    currentScore.value.title = scoreTitle.value
  }
}

const playComposition = () => {
  // 实现播放逻辑
  console.log('播放乐谱')
}

const saveScore = () => {
  // 实现保存逻辑
  console.log('保存乐谱')
}

const exportMidi = () => {
  // 实现导出逻辑
  console.log('导出MIDI')
}

const toggleMetronome = () => {
  metronomeOn.value = !metronomeOn.value
}

const addRest = () => {
  // 添加休止符
  console.log('添加休止符')
}

const addChord = () => {
  // 添加和弦
  console.log('添加和弦')
}

const undoAction = () => {
  // 撤销操作
  console.log('撤销')
}

const redoAction = () => {
  // 重做操作
  console.log('重做')
}

const deleteSelectedNote = () => {
  if (selectedNote.value) {
    scoreStore.removeNote(selectedNote.value.id)
    selectedNote.value = null
  }
}

const formatDate = (date: Date) => {
  return dayjs(date).format('YYYY-MM-DD HH:mm')
}

// 初始化画布
onMounted(() => {
  if (scoreId.value) {
    // 加载指定乐谱
    const score = scoreStore.scores.find(s => s.id === scoreId.value)
    if (score) {
      scoreStore.currentScore = score
      scoreTitle.value = score.title
      timeSignature.value = score.timeSignature
      keySignature.value = score.keySignature
      tempo.value = score.tempo
    }
  }
  
  // 初始化画布
  const ctx = canvas.value?.getContext('2d')
  if (ctx && canvas.value && canvasContainer.value) {
    canvas.value.width = canvasContainer.value.clientWidth
    canvas.value.height = canvasContainer.value.clientHeight
    
    // 绘制五线谱
    drawStaff(ctx)
  }
})

const drawStaff = (ctx: CanvasRenderingContext2D) => {
  ctx.strokeStyle = '#000'
  ctx.lineWidth = 1
  
  // 绘制多个五线谱系统
  for (let system = 0; system < 3; system++) {
    const yOffset = 50 + system * 200
    
    for (let i = 0; i < 5; i++) {
      const y = yOffset + i * 20
      ctx.beginPath()
      ctx.moveTo(50, y)
      ctx.lineTo(ctx.canvas.width - 50, y)
      ctx.stroke()
    }
    
    // 绘制小节线
    for (let i = 0; i < 4; i++) {
      const x = 50 + i * 200
      ctx.beginPath()
      ctx.moveTo(x, yOffset)
      ctx.lineTo(x, yOffset + 80)
      ctx.stroke()
    }
  }
}

// 监听画布容器大小变化
watch(canvasContainer, () => {
  if (canvas.value && canvasContainer.value) {
    canvas.value.width = canvasContainer.value.clientWidth
    canvas.value.height = canvasContainer.value.clientHeight
    
    const ctx = canvas.value.getContext('2d')
    if (ctx) {
      drawStaff(ctx)
    }
  }
}, { immediate: true })
</script>

<style scoped>
.score-editor {
  height: calc(100vh - 64px); /* 减去header高度 */
}

.score-display-area {
  background: linear-gradient(to right, #f9f9f9 0%, #fff 20px, #fff calc(100% - 20px), #f9f9f9 100%);
}

canvas {
  background: white;
  border: 1px solid #e5e7eb;
  border-radius: 4px;
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
}
</style>