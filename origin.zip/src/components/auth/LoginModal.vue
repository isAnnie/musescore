<template>
  <div class="modal-overlay" @click.self="$emit('close')">
    <div class="modal-content">
      <div class="modal-header">
        <h2 class="modal-title">登录 MuseScore Vue</h2>
        <button @click="$emit('close')" class="modal-close">
          <X class="w-5 h-5" />
        </button>
      </div>

      <div class="modal-body">
        <!-- 登录表单 -->
        <form @submit.prevent="handleLogin" class="space-y-4">
          <div>
            <label class="form-label">用户名或邮箱</label>
            <input
              v-model="form.username"
              type="text"
              required
              class="form-input"
              placeholder="请输入用户名或邮箱"
            />
          </div>

          <div>
            <label class="form-label">密码</label>
            <input
              v-model="form.password"
              type="password"
              required
              class="form-input"
              placeholder="请输入密码"
            />
          </div>

          <div class="flex items-center justify-between">
            <label class="flex items-center">
              <input type="checkbox" v-model="form.remember" class="mr-2" />
              <span class="text-sm">记住我</span>
            </label>
            <a href="#" class="text-sm text-blue-500 hover:text-blue-600">
              忘记密码？
            </a>
          </div>

          <button
            type="submit"
            :disabled="loading"
            class="btn-login"
          >
            <span v-if="!loading">登录</span>
            <span v-else>登录中...</span>
          </button>
        </form>

        <!-- 社交登录 -->
        <div class="social-login">
          <div class="divider">或使用社交账号登录</div>
          <div class="social-buttons">
            <button class="social-btn google">
              <img src="https://www.google.com/favicon.ico" alt="Google" class="social-icon" />
              Google
            </button>
            <button class="social-btn github">
              <Github class="social-icon" />
              GitHub
            </button>
          </div>
        </div>

        <!-- 注册链接 -->
        <div class="register-link">
          <span>还没有账号？</span>
          <a href="#" class="text-blue-500 hover:text-blue-600 font-medium">
            立即注册
          </a>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref } from 'vue'
import { useUserStore } from '@/stores/userStore'
import { X, Github } from 'lucide-vue-next'

const emit = defineEmits(['close', 'login-success'])

const userStore = useUserStore()
const loading = ref(false)

const form = ref({
  username: '',
  password: '',
  remember: false
})

const handleLogin = async () => {
  if (!form.value.username || !form.value.password) return

  loading.value = true
  try {
    await userStore.login(form.value.username, form.value.password)
    emit('login-success')
    emit('close')
  } catch (error) {
    console.error('登录失败:', error)
  } finally {
    loading.value = false
  }
}
</script>

<style scoped>
.modal-overlay {
  @apply fixed inset-0 bg-black bg-opacity-50 flex items-center 
         justify-center z-50;
}

.modal-content {
  @apply bg-white rounded-xl w-full max-w-md;
}

.modal-header {
  @apply flex items-center justify-between p-6 border-b;
}

.modal-title {
  @apply text-xl font-semibold text-gray-800;
}

.modal-close {
  @apply p-2 rounded-full hover:bg-gray-100 transition-colors;
}

.modal-body {
  @apply p-6;
}

.form-label {
  @apply block text-sm font-medium text-gray-700 mb-1;
}

.form-input {
  @apply w-full px-3 py-2 border rounded-lg focus:outline-none 
         focus:ring-2 focus:ring-blue-500 focus:border-transparent;
}

.btn-login {
  @apply w-full py-3 bg-blue-500 text-white rounded-lg 
         hover:bg-blue-600 transition-colors font-medium
         disabled:opacity-50 disabled:cursor-not-allowed;
}

.social-login {
  @apply mt-6;
}

.divider {
  @apply flex items-center my-4 text-center text-gray-500 text-sm;
}

.divider::before,
.divider::after {
  content: '';
  @apply flex-1 h-px bg-gray-300;
}

.divider::before {
  @apply mr-4;
}

.divider::after {
  @apply ml-4;
}

.social-buttons {
  @apply grid grid-cols-2 gap-3;
}

.social-btn {
  @apply flex items-center justify-center space-x-2 px-4 py-2 
         border rounded-lg hover:bg-gray-50 transition-colors;
}

.social-btn.google {
  @apply border-gray-300;
}

.social-btn.github {
  @apply border-gray-800 bg-gray-900 text-white hover:bg-gray-800;
}

.social-icon {
  @apply w-5 h-5;
}

.register-link {
  @apply mt-6 text-center text-gray-600;
}
</style>