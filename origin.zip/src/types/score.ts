export interface Note {
  id: string
  type: 'whole' | 'half' | 'quarter' | 'eighth' | 'sixteenth'
  pitch: string // 如 'C4', 'D5'
  duration: number
  position: { x: number; y: number }
  accidental?: 'sharp' | 'flat' | 'natural'
}

export interface TimeSignature {
  numerator: number
  denominator: number
}

export interface Score {
  id: string
  title: string
  composer: string
  tempo: number
  timeSignature: TimeSignature
  keySignature: string
  notes: Note[]
  createdAt: Date
  updatedAt: Date
}

export interface User {
  id: string
  username: string
  email: string
  avatar?: string
  scores: Score[]
}